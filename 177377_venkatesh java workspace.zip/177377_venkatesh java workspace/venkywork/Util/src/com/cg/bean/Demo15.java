package com.cg.bean;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Demo15 {
public static void main(String[] args) 
{
	// TODO Auto-generated method stub
String input="shop,mop,hopping,chopping,crop";
Pattern pattern=Pattern.compile("hop");
Matcher matcher=pattern.matcher(input);
while(matcher.find())
{
	System.out.println(matcher.group()+" "+matcher.start()+" "+matcher.end());
}
}
}
