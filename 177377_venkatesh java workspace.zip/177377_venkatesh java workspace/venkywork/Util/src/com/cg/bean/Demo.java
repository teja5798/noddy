package com.cg.bean;

public class Demo {
public static void main(String[] args) {
	//promotion and type casting
	long a=123456l;//int promoted to long
	System.out.println(a);
	int x=(int)a;//long type casted to int 
	System.out.println(x);
    double d=312.55;
    System.out.println(d);
    int y=(int)d;//double typecasted to int//fraction truncatated
    System.out.println(y);
    byte z=(byte)d;//double type casted to byte//fraction truncated and then dive by 256
   System.out.println(z); 
   char ch=65;//byte promoted to char 
   System.out.println(ch);
   int p=66;
   char ch1=(char)p;
   System.out.println(ch1);
   char c='A';
   
}
}
