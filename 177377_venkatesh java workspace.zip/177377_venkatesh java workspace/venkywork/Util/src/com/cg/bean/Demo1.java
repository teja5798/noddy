package com.cg.bean;

public class Demo1 {
public static void main(String[] args) {
	int a=100;
	System.out.println(a);
	Integer ob =new Integer(a);//boxing
	System.out.println(a);
	int b=ob.intValue();//unboxing
	System.out.println(b);
}
}
