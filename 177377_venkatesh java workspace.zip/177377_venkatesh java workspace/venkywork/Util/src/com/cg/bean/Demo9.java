package com.cg.bean;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Demo9 {
public static void main(String[] args) throws IOException {
	int c=0;
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Enter line");
	String line=br.readLine();
	StringTokenizer s=new StringTokenizer(line," ");
    while(s.hasMoreTokens()){
    	String word=s.nextToken();
    	System.out.println(word);
    c++;
    }
    System.out.println("Total words "+c);
}
}
