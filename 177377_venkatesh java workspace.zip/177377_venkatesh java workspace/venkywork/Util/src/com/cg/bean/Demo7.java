package com.cg.bean;

import java.util.Arrays;

public class Demo7 {
public static void main(String[] args) {
	byte b[]={65,66,67,68,69};
	String s1=new String(b);
	System.out.println(s1);
	byte buf[]=s1.getBytes();
	System.out.println(Arrays.toString(buf));
	char ch[]={'C','a','p','2'};
	String s2=new String(ch);
	System.out.println(s2);
	char ch1[]=s2.toCharArray();
	for (char c : ch1) {
		System.out.println(c);
		
	}
	for (char c : ch1) {
		System.out.println(c);
		if (Character.isUpperCase(c)) {
			System.out.println("UPPER");
		}
		if (Character.isLowerCase(c)) {
			System.out.println("LOWER");
		}
		if (Character.isDigit(c)) {
			System.out.println("Digits");
		}
	}
}
}
