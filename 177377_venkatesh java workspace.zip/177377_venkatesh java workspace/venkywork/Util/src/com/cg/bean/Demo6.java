package com.cg.bean;

import java.util.Arrays;

public class Demo6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
byte b[]={65,66,67,68,69};
String s1=new String(b);
System.out.println(s1);
byte buf[]=s1.getBytes();
System.out.println(Arrays.toString(buf));
char ch[]={'c','a','p'};
String s2=new String(ch);
System.out.println(s2);
char ch1[]=s2.toCharArray();
for (char c : ch1) {
	System.out.println(ch);
	
}
	}

}
