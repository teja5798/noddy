package com.cg.bean;

public class Demo3 {
public static	void calculate(Double d)//boxing
{
		d=d*0.05;//unboxing
		System.out.println(d);
	}
public static void main(String[] args) {
	//jdk 1.5 on words
	double a=100;
	calculate(a);
}
}
