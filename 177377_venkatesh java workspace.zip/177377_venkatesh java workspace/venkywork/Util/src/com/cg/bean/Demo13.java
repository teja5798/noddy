package com.cg.bean;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Demo13 {
	public static boolean validateMobile(String mobile){
		String mobilepattern="[0-9]{10}";
		boolean check=mobile.matches(mobilepattern);
		
		return check;
		
	}
public static void main(String[] args) throws IOException {
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	while(true){
		System.out.println("enter mobile number");
		String mobile=br.readLine();
		if(validateMobile(mobile)){
			System.out.println(mobile);
			break;
		}
	}
}
}
