package com.cg.bean;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Pattern;

public class Demo14 {
	public static boolean validateMobile(String mobile){
		String mobilepattern="[0-9]{10}";
		boolean check=Pattern.matches(mobilepattern,mobile);
		
		return check;
		
	}
public static void main(String[] args) throws IOException {
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	while(true){
		System.out.println("enter mobile number");
		String mobile=br.readLine();
		if(validateMobile(mobile)){
			System.out.println(mobile);
			break;
		}
	}
}
}
