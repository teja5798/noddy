package com.cg.bean;

public class Demo5 {
public static void main(String[] args) {
	String s1=String.valueOf(100);//int convert to String
	System.out.println(s1);
	String s2=String.valueOf(false);//boolean convert to String
	System.out.println(s2);
	String s3=String.valueOf(3.14);//double convert to String
	System.out.println(s3);
}
}
