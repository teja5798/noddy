package com.cg.bean;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Demo11 {
public static void main(String[] args) throws IOException, ParseException {
	int c=0;
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Enter Date in dd/mm/yyyy  hh:mm:ss");
	String mydate=br.readLine();
	SimpleDateFormat sdf=new SimpleDateFormat("dd/mm/yyyy hh:mm:ss");
	Date d1=sdf.parse(mydate);//string into Date Object
	System.out.println(d1);
	System.out.println(d1.getDate()+" "+d1.getMonth()+" "+d1.getYear());
	System.out.println(d1.getHours()+" "+d1.getMinutes()+" "+d1.getSeconds());
}
}
