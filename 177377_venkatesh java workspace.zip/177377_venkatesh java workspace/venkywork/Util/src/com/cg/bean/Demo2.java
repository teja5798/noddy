package com.cg.bean;

public class Demo2 {
public static void main(String[] args) {
	//jdk 1.5 on words
	int a=100;
	System.out.println(a);
	Integer ob =a;//auto boxing
	System.out.println(a);
	int b=ob;//auto unboxing
	System.out.println(b);
}
}
