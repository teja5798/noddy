package com.cg.bean;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Demo8 {
public static void main(String[] args) throws IOException {
	int c=0;
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Enter line");
	String line=br.readLine();
	String s[]=line.split(" ");
	for (String string : s) {
		System.out.println(string);
		c++;
	}
	System.out.println("Total Word count is :"+c);
	System.out.println("Enter date formate dd-mm-yyyy ");
	String date =br.readLine();
	String []d=date.split("-");
	for (String string : d) {
		System.out.println(string);
	}
}
}
