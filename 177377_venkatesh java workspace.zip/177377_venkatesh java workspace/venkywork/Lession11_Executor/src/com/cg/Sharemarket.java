package com.cg;

import java.util.concurrent.Callable;

public class Sharemarket implements Callable<Double> {

	@Override
	public Double call() throws Exception {
		// TODO Auto-generated method stub
		double d=Math.random()*1000.00;
		return d;
	}

}
