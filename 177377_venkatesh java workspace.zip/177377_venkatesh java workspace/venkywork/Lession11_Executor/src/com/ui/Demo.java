package com.ui;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import com.cg.*;
public class Demo {
public static void main(String[] args) {
	Runnable r=new MyRunnable();
	Executor executor=Executors.newSingleThreadExecutor();
	executor.execute(r);//automatic thread object and start thread and execute
	executor.execute(r);
	executor.execute(r);
	executor.execute(r);
}
}
