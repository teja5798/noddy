package com.ui;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.cg.MyRunnable;
public class Demo2 {
public static void main(String[] args) {
	//Executor pattern 
	Runnable r=new MyRunnable();
	ExecutorService executor=Executors.newSingleThreadExecutor();
	executor.execute(r);//automatic thread object and start thread and execute
	executor.execute(r);
	executor.execute(r);
	executor.execute(r);
	executor.shutdown();
}
}
