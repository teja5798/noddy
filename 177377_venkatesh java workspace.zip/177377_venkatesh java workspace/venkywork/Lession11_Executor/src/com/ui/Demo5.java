package com.ui;
import java.util.*;
import java.util.concurrent.*;


import com.cg.Sharemarket;;
public class Demo5 {

	public static void main(String[] args) {
	//Sharemarket sm=new Sharemarket();
		Callable<Double>sm=()->Math.random()*2000.00;
	ExecutorService executorService=Executors.newFixedThreadPool(10);
	List <Future<Double>>reslist=new ArrayList<>();
	for (int i = 0; i <=5; i++) {
		Future<Double>f=executorService.submit(sm);
		reslist.add(f);
	}
	try {
		executorService.awaitTermination(5, TimeUnit.SECONDS);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	executorService.shutdown();
	double price=0.0;
	for (Future<Double> future : reslist) {
		try {
			price=future.get();
		} catch (InterruptedException | ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(price);
	}
	}

}
