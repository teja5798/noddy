package cg;

public class Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="";
		String s2="CapGemini Solution Pvt Ltd";
		String s;
		if (s1.equals("")) {
			System.out.println("Empty String");//all version
		}if (s1.isEmpty()) {
			System.out.println("String is Empty");
			
		}
		int i=s2.length();
		System.out.println("String length"+i);
		int i1=s2.indexOf("emini");
		System.out.println(i1);
s=s2.substring(3,10);
System.out.println(s);
String name="  don  ";
System.out.println(name);
name=name.trim();
System.out.println(name);
double pi=3.14;
s=String.valueOf(pi);
System.out.println(s);
	}

}
