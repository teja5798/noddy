package cg;
import java.sql.*;
import java.util.*;
public class TestConnect6 {
public static void main(String[] args) {
	//load the driver
	try {
		//Class.forName("oracle.jdbc.driver.OracleDriver");
		//DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
	
	String url="jdbc:oracle:thin:@10.219.34.3:1521:orcl";
	String user="trg514";
	String pass="training514";
	
		Connection con=DriverManager.getConnection(url, user, pass);
		System.out.println("Connected");
		con.setAutoCommit(false);//tells that do not commit after every dml statement
		Scanner sc=new Scanner(System.in);
		System.out.println("enter Deparment ID");
		int d1=sc.nextInt();
		System.out.println("enter Deparment Name");
		String sname=sc.next();
		System.out.println("enter Deparment location");
		String sloc=sc.next();
		String sqlQuery="update dept set dname=?,location=? where did=?";
		
		PreparedStatement st=con.prepareStatement(sqlQuery);//use to pass sql queries
		st.setString(1, sname);
		st.setString(2, sloc);
		st.setInt(3, d1);
	
	
		int udaterec=	st.executeUpdate();
	System.out.println("inserted records  :"+udaterec);
		
		
	con.commit();
	con.close();
	 
	}
	catch (SQLException e)
	{
		System.out.println(e.getMessage()+" "+e.getErrorCode()+" "+e.getSQLState());
		e.printStackTrace();
	}
	

	}
}