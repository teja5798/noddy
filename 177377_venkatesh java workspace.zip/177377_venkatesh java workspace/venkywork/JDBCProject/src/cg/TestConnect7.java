package cg;
import java.sql.*;
import java.util.*;
public class TestConnect7 {
public static void main(String[] args) {
	//load the driver
	try {
		//Class.forName("oracle.jdbc.driver.OracleDriver");
		//DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
	
	String url="jdbc:oracle:thin:@10.219.34.3:1521:orcl";
	String user="trg514";
	String pass="training514";
	
		Connection con=DriverManager.getConnection(url, user, pass);
		System.out.println("Connected");
		con.setAutoCommit(false);//tells that do not commit after every dml statement
		Scanner sc=new Scanner(System.in);
		System.out.println("enter Deparment ID");
		int d1=sc.nextInt();
		
		String sqlQuery="delete from dept where did=?";
		
		PreparedStatement st=con.prepareStatement(sqlQuery);//use to pass sql queries
		
		st.setInt(1, d1);
	
	
		int udaterec=	st.executeUpdate();
	System.out.println("deleted records  :"+udaterec);
		
		
	con.commit();
	con.close();
	 
	}
	catch (SQLException e)
	{
		System.out.println(e.getMessage()+" "+e.getErrorCode()+" "+e.getSQLState());
		e.printStackTrace();
	}
	

	}
}