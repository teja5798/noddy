package cg;
import java.sql.*;
public class TestConnect3 {
public static void main(String[] args) {
	//load the driver
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	String url="jdbc:oracle:thin:@10.219.34.3:1521:orcl";
	String user="trg514";
	String pass="training514";
	try {
		Connection con=DriverManager.getConnection(url, user, pass);
		System.out.println("Connected");
		
		Statement st=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);//use to pass sql queries
	ResultSet rs=	st.executeQuery("select did,dname,location from dept");
	rs.afterLast();
	while (rs.previous()) {
		int d=rs.getInt("did");
		if (d==60) {
			rs.updateString("dname", "Account");
			rs.updateString(3, "Blr");
			rs.updateRow();//with this method only we can update the data base
		}
		String d_name=rs.getString("dname");
	String loc=	rs.getString(3);
	System.out.println("Dept id "+d+" DeptName "+d_name+" Location "+loc);
	System.out.println("===============================");
	
	}
	con.commit();
	con.close();
	} 
	catch (SQLException e)
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
}
