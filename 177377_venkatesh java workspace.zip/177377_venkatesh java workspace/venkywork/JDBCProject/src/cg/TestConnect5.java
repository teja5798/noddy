package cg;
import java.sql.*;
import java.util.*;
public class TestConnect5 {
public static void main(String[] args) {
	//load the driver
	try {
		//Class.forName("oracle.jdbc.driver.OracleDriver");
		//DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
	
	String url="jdbc:oracle:thin:@10.219.34.3:1521:orcl";
	String user="trg514";
	String pass="training514";
	
		Connection con=DriverManager.getConnection(url, user, pass);
		System.out.println("Connected");
		con.setAutoCommit(false);//tells that do not commit after every dml statement
		Scanner sc=new Scanner(System.in);
		System.out.println("enter Deparment ID");
		int d1=sc.nextInt();
		System.out.println("enter Deparment Name");
		String sname=sc.next();
		System.out.println("enter Deparment location");
		String sloc=sc.next();
		String sqlQuery="insert into dept values (?,?,?)";
		
		PreparedStatement st=con.prepareStatement(sqlQuery,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);//use to pass sql queries
	st.setInt(1, d1);
	st.setString(2, sname);
	st.setString(3, sloc);
		int insetrec=	st.executeUpdate();
	System.out.println("inserted records  :"+insetrec);
		
		
	con.commit();
	con.close();
	 
	}
	catch (SQLException e)
	{
		System.out.println(e.getMessage()+" "+e.getErrorCode()+" "+e.getSQLState());
		e.printStackTrace();
	}
	

	}
}