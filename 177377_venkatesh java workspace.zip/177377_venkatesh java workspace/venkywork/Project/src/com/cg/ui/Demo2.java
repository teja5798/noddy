package com.cg.ui;

import com.cg.bean.Employee;

public class Demo2 {
public static void main(String[] args) {
	 Employee e1=new  Employee(100,2500.23,"ram");
	 Employee e2=new  Employee(100,2500.23,"ram");
	 System.out.println(e1);
	 System.out.println(e2);
	 System.out.println(e1==e2);
	 System.out.println(e1.equals(e2));
	 //e1.equals(e2)-->Employee-->java.lang.Object
	 //object equals=>check for memory address refer
	 //when u override equals methode u have to also override
	 System.out.println(e1.hashCode()+" "+e2.hashCode());
}
}
