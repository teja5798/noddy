package com.cg.ui;

import com.cg.bean.Employee;

public class Demo1 {
public static void main(String[] args) {
	 Employee e1=new  Employee(100,2500.23,"ram");
	 Employee e2=new  Employee(101,2500.23,"venky");
	 System.out.println(e1);
	 System.out.println(e2);
	 //print class @hashcode of the object
	 //e1.toString()----->@hash code of the object
	 String mString="Details of Employee"+e1;
	 System.out.println(mString);
}
}
