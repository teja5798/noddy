package com.cg.ui;

public class Demo3 {
public static void main(String[] args) {
	StringBuffer buffer=new StringBuffer("hello");
	System.out.println("buffer : "+buffer);
	System.out.println("length : "+buffer.length());
	System.out.println("capacity : "+buffer.capacity());
	
	String s;
	int a=42;
	buffer =new StringBuffer(40);
	s=buffer.append("a=").append(a).append("!").toString();
	System.out.println(s);
buffer=new StringBuffer("i java");
buffer.insert(2, "like");
System.out.println(buffer);
buffer.reverse();
System.out.println(buffer);

}
}
