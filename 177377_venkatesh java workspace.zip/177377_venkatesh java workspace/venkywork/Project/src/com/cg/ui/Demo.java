package com.cg.ui;

import com.cg.bean.Employee;

public class Demo {
public static void main(String[] args) {
	 Employee e1=new  Employee(100,2500.23,"ram");
	 Employee e2=new  Employee(101,2500.23,"venky");
	 e1=e2;
	 //indicate garbage collector to execute 
	 System.gc();
	 System.out.println("done");

}
}
