package com.cg.ui;
import static java.lang.Math.*;
import static java.lang.System.*;
//jdk 1.5 onwords  static variables and method can be imported
public class Demo4 {
public static void main(String[] args) {
	System.out.println(PI);
	double res=sqrt(4);
	out.print(res);
}
}
