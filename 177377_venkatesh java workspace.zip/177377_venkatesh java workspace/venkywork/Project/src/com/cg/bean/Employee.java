package com.cg.bean;

public class Employee {
	private int eid;
	private	double salary;
	private String name;
public Employee() {
	// TODO Auto-generated constructor stub
}
public Employee(int eid, double salary, String name) {
	super();
	this.eid = eid;
	this.salary = salary;
	this.name = name;
}
public int getEid() {
	return eid;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + eid;
	result = prime * result + ((name == null) ? 0 : name.hashCode());
	long temp;
	temp = Double.doubleToLongBits(salary);
	result = prime * result + (int) (temp ^ (temp >>> 32));
	return result;
}
@Override
public boolean equals(Object obj) {
	Employee e=(Employee)obj;
	if (this.getEid()==e.getEid()&&this.getSalary()==e.getSalary()&&this.getName().equals(e.getName())) {
		return true;
		
	}
	else
		return false;
}
public void setEid(int eid) {
	this.eid = eid;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
//when object is destroyed by grabaze collection finalize is execute 
@Override
public void finalize() throws Throwable {
	System.out.println("Destroyed emopyee"+eid);
}
@Override
public String toString() {
	return "Employee [eid=" + eid + ", salary=" + salary + ", name=" + name
			+ "]";
}
}
