package cg;

import java.io.IOException;
import cg.exception.*;
import cg.exception.SalaryException;

public class Demo7 {
	public static void checkSal(int x) throws SalaryException{
	if (x<3000) {
		throw new SalaryException(x+"salary should be more than 3000");//unchecked exception
	}
	
	
	}
	
public static void main(String[] args) {
	int a=0;
	try {
		
	
	a=Integer.parseInt(args[0]);
	checkSal(a);
	System.out.println(a);
	
	} catch (Exception e) {
		System.out.println(e.getMessage());
		e.printStackTrace();
	}                                                            
	System.out.println("Continue program");
}
}
/*
1.no command line  argument==>array out of bounds Exception
2.args[0]=aa==>number formate exception
3.arg[0]=0==>arithmatic exception

*/