package cg;

import java.io.IOException;

public class Demo5 {
	public static void change(int x) throws IOException{
		x=System.in.read();//line throwsIOException at compile time means checked Exception
	System.out.println(x);
	}
	
public static void main(String[] args) {
	int a=0;
	try {
		
	
	a=Integer.parseInt(args[0]);
	change(a);
	System.out.println(a);
	
	} catch (Exception e) {
		System.out.println(e.getMessage());
		e.printStackTrace();
	}                                                            
	System.out.println("Continue program");
}
}
/*
1.no command line  argument==>array out of bounds Exception
2.args[0]=aa==>number formate exception
3.arg[0]=0==>arithmatic exception

*/