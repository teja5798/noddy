package cg;

public class Demo1 {
	public static void change(int x){
		x=100/x;
	}
public static void main(String[] args) {
	int a=0;
	try {
		
	
	a=Integer.parseInt(args[0]);
	change(a);
	System.out.println(a);
	
	} catch (ArrayIndexOutOfBoundsException e) {
		System.out.println(e.getMessage());
		e.printStackTrace();
	}
	catch (NumberFormatException e) {
		// TODO: handle exception
		System.out.println(args[0]+" can not be parsed to number");
	}
	catch (ArithmeticException e) {
		// TODO: handle exception
	e.printStackTrace();
	}
	System.out.println("Continue program");
}
}
/*
1.no command line  argument==>array out of bounds Exception
2.args[0]=aa==>number formate exception
3.arg[0]=0==>arithmatic exception

*/