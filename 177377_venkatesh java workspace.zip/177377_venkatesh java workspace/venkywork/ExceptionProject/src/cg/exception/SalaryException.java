package cg.exception;

public class SalaryException extends Exception{
public SalaryException() {
	// TODO Auto-generated constructor stub
}
public SalaryException(String message) {
	// TODO Auto-generated constructor stub
	super(message);
}
@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "cg.exception.SalaryException"+super.getMessage();
	}
}
