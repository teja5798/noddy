package com.cg.eis.dao;

import java.util.Map;

import com.cg.eis.Bean.Account;

public interface AccountDAO {
	public boolean validateMobile(String mobile);
	public boolean createAccount(Account ac);
	public double add(double amount,Account ac);
	public Account updateAccount(Account ac);
	public boolean delete(int mobileNumber);
	public boolean transferMoney(Account ac1,Account ac2);
	public Account getAccountBymobile(int mobileNo);
	public Map<Integer, Account>getAllAccount();

}
