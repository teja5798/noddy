package com.cg.eis.services;

import java.util.Map;

import com.cg.eis.Bean.Account;
import com.cg.eis.dao.AccountDAO;
import com.cg.eis.dao.AccountDaoImpl;

public class WalletServiceImpl implements WalletService {
/*
 * WalletService is connecting to AccountDAO
 * */
	AccountDAO accountdao=new AccountDaoImpl();
	@Override
	public boolean validateMobile(String mobile) {

		boolean m=false;
		m=mobile.matches(mobilePattern);
		
		return m;
	}

	@Override
	public boolean createAccount(Account ac) {
		// TODO Auto-generated method stub
		return accountdao.createAccount(ac);
	}

	@Override
	public Account getAccountBymobile(int mobileNo) {
		// TODO Auto-generated method stub
		return accountdao.getAccountBymobile(mobileNo);
	}

	@Override
	public Map<Integer, Account> getAllAccount() {
		// TODO Auto-generated method stub
		return accountdao.getAllAccount();
	}

	@Override
	public double add(double amount, Account ac) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Account updateAccount(Account ac) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean delete(int mobileNumber) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean transferMoney(Account ac1, Account ac2) {
		// TODO Auto-generated method stub
		return false;
	}

}
