package com.cg.beean;

public class TransactionRunnable5 implements Runnable {
int balace=1000;
boolean valueSet=false;
	@Override
	public void run() {
	String string=Thread.currentThread().getName();
	for (int i = 0; i <= 10; i++) {
		if (string.equals("Sham")) {
			
		
		deposite(1000);}
		if (string.equals("Ram")) {
			printBalance();
		}
	}
		
		
		}
	

	public synchronized void deposite(int i) {
		if (!valueSet) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else {
	System.out.println("Thread strat ::::"+Thread.currentThread().getName());
	System.out.println("before deposite:::: "+balace);
	balace=balace+i;
	System.out.println("after deposote ::::: "+balace);
	System.out.println("Thread ended ::::"+Thread.currentThread().getName());
	valueSet=false;
	notify();
		}
	}
public synchronized void printBalance()
	{if (valueSet) {
		try {
			wait();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} else {

	
	System.out.println("Thread ::::: "+Thread.currentThread().getName());
		System.out.println("Balance "+balace);
		valueSet=true;
		notify(); 
		}
	}

}
