package com.cg.beean;

public class TransactionRunnable4 implements Runnable {
int balace=1000;
	@Override
	public void run() {
	String string=Thread.currentThread().getName();
	for (int i = 0; i <= 10; i++) {
		if (string.equals("Sham")) {
			
		
		deposite(1000);}
		if (string.equals("Ram")) {
			printBalance();
		}
	}
		
		
		}
	

	public synchronized void deposite(int i) {
		// TODO Auto-generated method stub
	System.out.println("Thread strat ::::"+Thread.currentThread().getName());
	System.out.println("before deposite:::: "+balace);
	balace=balace+i;
	System.out.println("after deposote ::::: "+balace);
	System.out.println("Thread ended ::::"+Thread.currentThread().getName());
	
	}
public synchronized void printBalance()
	{
	System.out.println("Thread ::::: "+Thread.currentThread().getName());
		System.out.println("Balance "+balace);
	}

}
