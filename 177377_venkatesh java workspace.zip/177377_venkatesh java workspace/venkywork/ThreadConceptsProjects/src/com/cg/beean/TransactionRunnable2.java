package com.cg.beean;

public class TransactionRunnable2 implements Runnable {
int balace=1000;
	@Override
	public void run() {
		// TODO Auto-generated method stub
		deposite(1000);
	}

	public synchronized void deposite(int i) {
		// TODO Auto-generated method stub
	System.out.println("Thread strat ::::"+Thread.currentThread().getName());
	System.out.println("before deposite:::: "+balace);
	balace=balace+i;
	System.out.println("after deposote ::::: "+balace);
	System.out.println("Thread ended ::::"+Thread.currentThread().getName());
	
	}
public void printBalance()
	{
		System.out.println("Balance "+balace);
	}

}
