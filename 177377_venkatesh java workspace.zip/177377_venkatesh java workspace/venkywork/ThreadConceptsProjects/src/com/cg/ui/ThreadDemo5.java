package com.cg.ui;

import com.cg.beean.TransactionRunnable5;

public class ThreadDemo5 {
public static void main(String[] args) {
	TransactionRunnable5 tr=new TransactionRunnable5();
	Thread producer=new Thread(tr,"Sham");
	Thread consumer=new Thread(tr,"Ram");
	
	producer.start();
	consumer.start();
	
	try {
		producer.join();
		
		consumer.join();
		
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.err.println(e.getMessage());
		
	}
	System.out.println("All threads are dead ,exiting main thread");
}

}
