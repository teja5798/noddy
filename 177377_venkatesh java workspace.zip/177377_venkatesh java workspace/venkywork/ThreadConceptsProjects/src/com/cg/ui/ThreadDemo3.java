package com.cg.ui;

import com.cg.beean.TransactionRunnable3;

public class ThreadDemo3 {
public static void main(String[] args) {
	TransactionRunnable3 tr=new TransactionRunnable3();
	Thread t=new Thread(tr,"Sham");
	Thread t1=new Thread(tr,"Ram");
	Thread t2=new Thread(tr,"Krishna");

	t.start();
	t1.start();
	t2.start();
	try {
		t.join();
		t1.join();
		t2.join();
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.err.println(e.getMessage());
		
	}
	System.out.println("All threads are dead ,exiting main thread");
}

}
