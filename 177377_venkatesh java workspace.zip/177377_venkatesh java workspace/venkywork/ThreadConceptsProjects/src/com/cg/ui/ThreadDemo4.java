package com.cg.ui;

import com.cg.beean.TransactionRunnable4;

public class ThreadDemo4 {
public static void main(String[] args) {
	TransactionRunnable4 tr=new TransactionRunnable4();
	Thread producer=new Thread(tr,"Sham");
	Thread consumer=new Thread(tr,"Ram");
	
	producer.start();
	consumer.start();
	
	try {
		producer.join();
		//Thread.sleep(4000);
		consumer.join();
		
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.err.println(e.getMessage());
		
	}
	System.out.println("All threads are dead ,exiting main thread");
}

}
