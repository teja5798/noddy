package com.cg.ui;

import com.cg.beean.TransactionRunnable2;

public class ThreadDemo2 {
public static void main(String[] args) {
	TransactionRunnable2 tr=new TransactionRunnable2();
	Thread t=new Thread(tr,"Sham");
	Thread t1=new Thread(tr,"Ram");
	Thread t2=new Thread(tr,"Krishna");

	t.start();
	t1.start();
	t2.start();
	try {
		t.join();
		t1.join();
		t2.join();
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.err.println(e.getMessage());
		
	}
	System.out.println("All threads are dead ,exiting main thread");
}

}
