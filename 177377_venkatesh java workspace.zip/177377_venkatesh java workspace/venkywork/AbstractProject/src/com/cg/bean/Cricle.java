package com.cg.bean;

public class Cricle extends Shape {
private double r;
public Cricle() {
	// TODO Auto-generated constructor stub
}

	public Cricle(double r) {
	super();
	this.r = r;
}

	public double getR() {
	return r;
}
public void setR(double r) {
	this.r = r;
}
	@Override
	public void area() {
		// TODO Auto-generated method stub
		double area=pi*r*r;
		System.out.println("Area of the cricle : "+area);
		
	}

}
