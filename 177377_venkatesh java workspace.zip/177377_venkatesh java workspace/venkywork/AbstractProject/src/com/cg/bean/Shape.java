package com.cg.bean;

public abstract class Shape {
protected final double pi=3.14;

public void ShowPi() {
	// TODO Auto-generated method stub
System.out.println("PI is :"+pi);
}
public abstract void area();//no method body
}
