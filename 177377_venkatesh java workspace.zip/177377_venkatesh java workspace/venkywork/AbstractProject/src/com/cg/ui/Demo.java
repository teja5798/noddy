package com.cg.ui;
import com.cg.bean.*;
public class Demo {
public static void main(String[] args) {
	//Shape s=new Shape();//error //abstract class can not be instantiated
Shape s=new Cricle(15);
s.area();
s.ShowPi();
s=new Rectangle(10,15);
s.area();
}
}
