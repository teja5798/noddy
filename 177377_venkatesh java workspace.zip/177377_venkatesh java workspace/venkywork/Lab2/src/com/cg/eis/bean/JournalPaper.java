package com.cg.eis.bean;

public class JournalPaper extends WrittenItem {
	private int YOP;
	public JournalPaper() {
		
	}

	public JournalPaper(int id, String title, int nocopies, String authorname, int age,int YOP){
		super(id, title, nocopies, authorname, age);
	 this.YOP=YOP;
	}

	

	@Override
	public String toString() {
		return super.toString()+" JournalPaper [YOP=" + YOP + "]";
	}

	@Override
	public void printDetails() {
		
		
	}

	@Override
	public void checkIn() {
	
		
	}

	@Override
	public void checkOut() {
		
		
	}

	@Override
	public void addItem() {
		
		
	}
	public void printDetails1()
	{
		super.toString();
		this.toString();
		
	}
	

}
