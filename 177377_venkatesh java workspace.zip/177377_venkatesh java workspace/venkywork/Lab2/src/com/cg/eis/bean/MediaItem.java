package com.cg.eis.bean;

public abstract class MediaItem extends Item {
	public MediaItem() {
		
	}

	public MediaItem(int id, String title, int nocopies) {
		super(id, title, nocopies);
	
	}

	@Override
	public String toString() {
		return super.toString()+"MediaItem []";
	}

}
