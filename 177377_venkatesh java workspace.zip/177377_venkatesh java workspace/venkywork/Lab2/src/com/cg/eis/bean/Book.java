package com.cg.eis.bean;

public class Book extends WrittenItem{

	
	public Book() {
	
}

public Book(int id, String title, int nocopies, String authorname, int age) {
		super(id, title, nocopies, authorname, age);
}

@Override
public String toString() {
	return "Book []";
}

@Override
public void printDetails() {
toString();	

}

@Override
public void checkIn() {
	
	
}

@Override
public void checkOut() {
	
	
}

@Override
public void addItem() {
	// TODO Auto-generated method stub
	
}
}
