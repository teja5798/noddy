package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Book;
import com.cg.eis.bean.CD;
import com.cg.eis.bean.Item;
import com.cg.eis.bean.JournalPaper;
import com.cg.eis.bean.Video;

public class Demo {

	public static void main(String[] args) {
		int id,nocopies,age,YOP;
		Item it;
		String title,authorname;
	String director,genre;
	int year;
	String artist;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter item id");
	id=sc.nextInt();
	System.out.println("Enter no of copies");
   nocopies=sc.nextInt();
   System.out.println("enter item title");
   title=sc.next();
   
   System.out.println("Select any one");
   System.out.println("1.Book\t2.JournalPaper\t3.Video\t4.CD");
   int ch=sc.nextInt();
   do
   {
	   switch(ch)
	   {
	   case 1:
		   System.out.println("Enter author name");
		   authorname=sc.next();
		   System.out.println("Enter age");
		   age=sc.nextInt();
		   it=new Book(id,title,nocopies,authorname,age);
		   System.out.println(it);
		   break;
	   case 2:
		   System.out.println("Enter author name");
		   authorname=sc.next();
		   System.out.println("Enter age");
		   age=sc.nextInt();
		   System.out.println("Enter yop");
		   YOP=sc.nextInt();
		   it=new JournalPaper(id,title,nocopies,authorname,age,YOP);
		   System.out.println(it);
		   break;
	   case 3:
		   System.out.println("enter director name");
		   director=sc.next();
		   System.out.println("Enter genre ");
		   genre=sc.next();
		   System.out.println("Enter year of release");
		   year=sc.nextInt();
		   it=new Video(id,title,nocopies,director,genre,year);
		   System.out.println(it);
		   break;
	   case 4:
		   System.out.println("Enter artist name");
		   artist=sc.next();
		   System.out.println("Enter genre");
		   genre=sc.next();
		   it=new CD(id,title,nocopies,artist,genre);
		   System.out.println(it);
		   break;
		   
		   default:
			   System.out.println("Invalid option");
			   break;
	   }
	   System.out.println("1.Book\t2.JournalPaper\t3.Video\t4.CD");
	   ch=sc.nextInt();
   }
	   while(ch!=0);
   }
	
	

	}


