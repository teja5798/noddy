package com.cg.eis.bean;

public class Video extends MediaItem{
	
private String director;
private String genre;
private int year;
public Video() {
	
}
public Video(int id, String title, int nocopies,String director,String genre,int year) {
	super(id, title, nocopies);
	this.director=director;
	this.genre=genre;
	this.year=year;
	
}
public String getDirector() {
	return director;
}
public void setDirector(String director) {
	this.director = director;
}
public String getGenre() {
	return genre;
}
public void setGenre(String genre) {
	this.genre = genre;
}
public int getYear() {
	return year;
}
public void setYear(int year) {
	this.year = year;
}
@Override
public String toString() {
	return super.toString()+"Video [director=" + director + ", genre=" + genre + ", year=" + year + "]";
}
@Override
public void printDetails() {
	toString();
	
}
@Override
public void checkIn() {
	
	
}
@Override
public void checkOut() {
	
}
@Override
public void addItem() {
	
	
}
}