package com.cg.eis.bean;

public abstract class WrittenItem extends Item{
	
	private String authorname;
	private int age;
	public WrittenItem() {
		
	}
	
	
	
	public WrittenItem(int id, String title, int nocopies,String authorname,int age) {
		super(id, title, nocopies);
		this.authorname=authorname;
		this.age=age;
	}



	
	public String getAuthorname() {
		return authorname;
	}
	public void setAuthorname(String authorname) {
		this.authorname = authorname;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return super.toString()+"WrittenItem [authorname=" + authorname + ", age=" + age + "]";
	}

}
