package com.cg.eis.bean;

public abstract class Item {
private int id;
private String title;
private int nocopies;
public Item() {
	// TODO Auto-generated constructor stub
}
public Item(int id, String title, int nocopies) {
	super();
	this.id = id;
	this.title = title;
	this.nocopies = nocopies;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public int getNoofcopes() {
	return nocopies;
}
public void setNoofcopes(int nocopies) {
	this.nocopies = nocopies;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Item other = (Item) obj;
	if (id != other.id)
		return false;
	if (nocopies != other.nocopies)
		return false;
	if (title == null) {
		if (other.title != null)
			return false;
	} else if (!title.equals(other.title))
		return false;
	return true;
}
@Override
public String toString() {
	return "Item [id=" + id + ", title=" + title + ", nocopies=" + nocopies
			+ "]";
}
public abstract void printDetails();
public abstract void checkIn();
public abstract void checkOut();
public abstract void addItem();

}
