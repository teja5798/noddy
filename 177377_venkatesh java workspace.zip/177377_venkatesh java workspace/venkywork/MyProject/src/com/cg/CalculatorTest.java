package com.cg;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;

class CalculatorTest {

	//@Test
	@RepeatedTest(5)
	void testadd() {
		System.out.println("CalculaterTest:test case testadd");
		Calulator ob= new Calulator();
		assertEquals(9,ob.add(4, 5));
	}

}
