package com.cg;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

class CalulatorTest1 {
static Calulator ob;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		System.out.println("calculater test1 : before all test");
		ob=new Calulator();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		System.out.println("calculator Test1: after all test ");
		ob=null;
	}
@Disabled
	@Test
	void testupperString() {
		System.out.println("Calculator test1: test case testupperString");
		assertNotNull(ob.upperString("cg"));
		assertNull(ob.upperString(null));
		assertEquals("cg", ob.upperString("cg"));
	}
	@Test
	void testValidateMobile()
	{
		System.out.println("CalculatorTest2:test case test validateMobile");
		assertTrue(ob.validateMobile("8297166136"));
		assertFalse(ob.validateMobile("2556456445645644564"));
		assertFalse(ob.validateMobile("23126@2233"));
		assertFalse(ob.validateMobile("31232hvhgf"));
	}

}
