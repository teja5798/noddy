package com.cg;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

class CalulatorTest2 {
	@ParameterizedTest
	@ValueSource(strings= {"6556456469","1231232223","2223350625"})
	void testValidateMobile(String strings)
	{
		System.out.println("CalculatorTest2:test case test validateMobile");
		System.out.println("paramers" +strings);
		Calulator ob=new Calulator();
		assertTrue(ob.validateMobile(strings));
	}
		@ParameterizedTest
		@CsvSource({"9,4,5","50,20,30,","100,50,50"})
		void testadd(int result,int firstno,int secondno) {
			System.out.println("parameter "+result+","+firstno+","+secondno);
			Calulator ob=new Calulator();
			assertEquals( +result, ob.add(firstno, secondno));
			
	}

}
