package com.cg;

public class Calulator {
public int add(int a,int b){
	return a+b;
}
public boolean validateMobile(String mobile) {
	return mobile.matches("[0-9]{10}");
	
}
public String upperString(String s) {
	if(s==null) {
		return null;
	}
	else {
		return s.toLowerCase();
	}
}
}
