package com.cg;

public class Trasaction {
private double balance;

public Trasaction(double balance) {
	super();
	this.balance = balance;
}

public double deposite(double amount)  {
	if (amount<=0) {
		throw new IllegalArgumentException("Negative Amount");
	}
	balance=balance+amount;
	return balance;
	}
	
}
