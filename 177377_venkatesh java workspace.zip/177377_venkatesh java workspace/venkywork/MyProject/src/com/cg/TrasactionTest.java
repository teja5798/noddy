package com.cg;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.Before;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TrasactionTest {
Trasaction t;
	@BeforeAll
static void beforeAllTest()
{
	System.out.println("TrasaTion Test: Before all test");
	
}
	@BeforeEach
	void beforeEachTest() {
		
		System.out.println("Traction Test :before Each test ");
		t=new Trasaction(1000.00);
		
	}
	
	@AfterEach
	void afterEachTest()
	{
		System.out.println("TrasaTion Test: After each test");
	t=null;
	}
	
	
	
	@AfterAll
	static void afterAllTest()
	{
		System.out.println("TrasaTion Test: after all test");
		
	}
	@Test
	void testdeposite1() {
		System.out.println("Traction Test:test case testdeposite1");
		assertEquals(3000.00,t.deposite(2000.00));
	}
	@Test
	void testdeposite2() {
		System.out.println("Traction Test:test case testdeposite2");
		//assertEquals(1000.00,t.deposite(-2000.00));
		Throwable ex=assertThrows(IllegalArgumentException.class, ()->t.deposite(-2000));
	}

}
