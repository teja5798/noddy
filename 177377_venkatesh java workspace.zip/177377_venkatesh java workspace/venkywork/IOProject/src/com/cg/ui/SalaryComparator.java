package com.cg.ui;
import java.util.Comparator;

import com.cg.bean.*;

public class SalaryComparator implements Comparator<Employee> {

	@Override
	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		System.out.println("compare method by salary");
		double diff=o1.getSalary()-o2.getSalary();
		if(diff>0)
			return 1;
					else if (diff<0) {
						return -1;
					}
		return 0;
	}

}
