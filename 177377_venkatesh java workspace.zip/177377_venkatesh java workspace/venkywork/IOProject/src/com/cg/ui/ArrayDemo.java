package com.cg.ui;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.cg.bean.*;
public class ArrayDemo {
public static void main(String[] args) throws IOException {
	Employee emp[]=new Employee[3];
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	for (int i = 0; i < emp.length; i++) {
		System.out.println("Enter employee id");
		String seid=br.readLine();
		int id=Integer.parseInt(seid);
		System.out.println("Enter employee name");
		String name=br.readLine();
		System.out.println("Enter employee salary");
		String ssal=br.readLine();
		double sal=Double.parseDouble(ssal);
		emp[i]=new Employee(id, name, sal);
		
}
	for (Employee employee : emp) {
		System.out.println(employee);
	}
}
}
