package com.cg.ui;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.TreeSet;

import com.cg.bean.*;
public class ListDemo2 {
public static void main(String[] args) throws IOException {
	Comparator namec=new NameComparator();
	Comparator salc=new SalaryComparator();
//ArrayList<Employee>elist=new ArrayList<Employee>();
	TreeSet<Employee>elist=new TreeSet<Employee>();
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Number of Employees");
	int n=Integer.parseInt(br.readLine());
	for (int i = 0; i <n; i++) {
		System.out.println("Enter employee id");
		String seid=br.readLine();
		int id=Integer.parseInt(seid);
		System.out.println("Enter employee name");
		String name=br.readLine();
		System.out.println("Enter employee salary");
		String ssal=br.readLine();
		double sal=Double.parseDouble(ssal);
		Employee ob=new Employee(id, name, sal);
	boolean a=	elist.add(ob);
		System.out.println("added employee "+a);
}
	for (Employee employee : elist) {
		System.out.println(employee);
	}
}
}
