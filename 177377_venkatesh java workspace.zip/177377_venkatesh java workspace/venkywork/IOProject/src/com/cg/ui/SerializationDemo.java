package com.cg.ui;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import com.cg.bean.*;
public class SerializationDemo {
public static void serialize(Employee e) throws IOException{
	FileOutputStream fo=new FileOutputStream("emp.ser");
	ObjectOutputStream obs=new ObjectOutputStream(fo);
	obs.writeObject(e);
	fo.close();
	obs.close();
}
public static void main(String[] args) throws IOException {
	Employee e=new Employee(100, "venky", 10000);
	e.os="windows";
	System.out.println(e);
	serialize(e);
}
}
