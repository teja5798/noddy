package com.cg.ui;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.cg.bean.*;
public class DeSerilization {
	public static Employee deSerialize() throws IOException, ClassNotFoundException{
		FileInputStream fi=new FileInputStream("emp.ser");
		ObjectInputStream obs=new ObjectInputStream(fi);
		Employee emp=(Employee )obs.readObject();
		fi.close();
		obs.close();
		return emp;
}
	public static void main(String[] args) throws ClassNotFoundException, IOException {
		Employee e=deSerialize();
		System.out.println(e);
		
	}
	}
