package com.cg.ui;
import com.cg.bean.*;
import java.util.Comparator;
public class NameComparator implements Comparator<Employee> {

	@Override
	public int compare(Employee arg0, Employee arg1) {
		// TODO Auto-generated method stub
		System.out.println("comparetor method");
		int res=arg0.getEname().compareTo(arg1.getEname());
		return res;
	}



}
