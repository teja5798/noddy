package com.cg.bean;
import java.io.*;

import javax.imageio.stream.FileImageInputStream;
public class CopyFile2 
{
	BufferedReader br;
	PrintWriter out;
FileReader  fromFile;
FileWriter toFile;
	public  void init(String args1,String args2) throws IOException {
		try {
			fromFile=new FileReader(args1);
			br= new BufferedReader(fromFile);
			toFile=new FileWriter(args2);
			out=new PrintWriter(toFile,true);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Exception "+e);
			throw e;
		}catch (IOException e) {
			// TODO: handle exception
			System.out.println("Exception"+e);
			throw e;
		}
		
		
		
	}
public void copyContents() throws IOException
{
	try {
		String line=br.readLine();
		while(line!=null){
			out.print(line);
			line=br.readLine();
		}
	} catch (IOException e) {
		// TODO Auto-generated catch block
		System.out.println("exception "+e);
		e.printStackTrace();
	throw e;
	}
	finally{
		if(fromFile!=null)
			fromFile.close();
		if (toFile!=null) {
			toFile.close();
		}
	}
}public static void main(String[] args) throws IOException {
	CopyFile2 c1=new CopyFile2();
	try {
		c1.init("aa.txt", "dd.txt");
		c1.copyContents();
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		System.out.println("caught in main "+e);
		e.printStackTrace();
	}
	
}
}
