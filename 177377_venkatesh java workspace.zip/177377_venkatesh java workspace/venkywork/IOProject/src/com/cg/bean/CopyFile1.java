package com.cg.bean;
import java.io.*;

import javax.imageio.stream.FileImageInputStream;
public class CopyFile1 {
FileReader  fromFile;
FileWriter toFile;
	public  void init(String args1,String args2) throws IOException {
		try {
			fromFile=new FileReader(args1);
			toFile=new FileWriter(args2);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Exception "+e);
			throw e;
		}catch (IOException e) {
			// TODO: handle exception
			System.out.println("Exception"+e);
			throw e;
		}
		
		
		
	}
public void copyContents() throws IOException
{
	try {
		int i=fromFile.read();
		while(i!=-1){
			toFile.write(i);
			i=fromFile.read();
		}
	} catch (IOException e) {
		// TODO Auto-generated catch block
		System.out.println("exception "+e);
		e.printStackTrace();
	throw e;
	}
	finally{
		if(fromFile!=null)
			fromFile.close();
		if (toFile!=null) {
			toFile.close();
		}
	}
}public static void main(String[] args) throws IOException {
	CopyFile1 c1=new CopyFile1();
	try {
		c1.init("aa.txt", "cc.txt");
		c1.copyContents();
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		System.out.println("caught in main "+e);
		e.printStackTrace();
	}
	
}
}
