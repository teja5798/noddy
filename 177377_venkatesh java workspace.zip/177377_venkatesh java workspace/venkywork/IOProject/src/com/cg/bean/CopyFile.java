package com.cg.bean;
import java.io.*;

import javax.imageio.stream.FileImageInputStream;
public class CopyFile {
FileInputStream  fromFile;
FileOutputStream toFile;
	public  void init(String args1,String args2) throws FileNotFoundException {
		try {
			fromFile=new FileInputStream(args1);
			toFile=new FileOutputStream(args2);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Exception "+e);
			throw e;
		}
		
		
		
	}
public void copyContents() throws IOException
{
	try {
		int i=fromFile.read();
		while(i!=-1){
			toFile.write(i);
			i=fromFile.read();
		}
	} catch (IOException e) {
		// TODO Auto-generated catch block
		System.out.println("exception "+e);
		e.printStackTrace();
	throw e;
	}
	finally{
		if(fromFile!=null)
			fromFile.close();
		if (toFile!=null) {
			toFile.close();
		}
	}
}public static void main(String[] args) throws IOException {
	CopyFile c1=new CopyFile();
	try {
		c1.init("aa.txt", "bb.txt");
		c1.copyContents();
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		System.out.println("caught in main "+e);
		e.printStackTrace();
	}
	
}
}
