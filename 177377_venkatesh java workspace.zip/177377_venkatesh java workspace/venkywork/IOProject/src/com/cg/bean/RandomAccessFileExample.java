package com.cg.bean;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class RandomAccessFileExample {
public static void main(String[] args) {
	try {
		String filepath="data.txt";
		String data=new String(readCharsFromFile(filepath,0));
		System.out.println(data);
		writeData(filepath,"hello",data.length());
		appendData(filepath,"venky");
	} catch (Exception e) {
		// TODO: handle exception
	}
}

private static void appendData(String filepath, String data) throws IOException {
	// TODO Auto-generated method stub
	RandomAccessFile raFile=new RandomAccessFile(filepath, "rw");
	raFile.seek(raFile.length());
	System.out.println("current pointer = "+raFile.getFilePointer());
	raFile.write(data.getBytes());
	raFile.close();
}

private static void writeData(String filepath, String data, int seek) throws IOException {
RandomAccessFile file=new RandomAccessFile(filepath,"rw");
file.seek(seek);
file.write(data.getBytes());
file.close();
	
}

private static byte[] readCharsFromFile(String filepath, int i) throws IOException {
	// TODO Auto-generated method stub
	RandomAccessFile file=new RandomAccessFile(filepath,"r");
	file.seek(i);
	byte[]bs=new byte[(int)file.length()];
	file.read(bs);
	file.close();
	return bs;
}
}
