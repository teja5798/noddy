package com.cg.bean;
import com.cg.service.GST;
public class SavingAccount extends Account implements GST{
 private double intrest;

 public double getIntrest() {
	return intrest;
}

public void setIntrest(  double intrest) {
	
	if(intrest>0)
	this.intrest = intrest;
}

public SavingAccount(int acno,String name,double bal,double intrest) {
	super(acno,name,bal);
	
	this.intrest = intrest;
}

@Override
	public void printDetails() {
		// TODO Auto-generated method stub
		super.printDetails();
		System.out.println("intrest is :"+intrest);
	}



@Override
	public double withdraw(double amount) {
		// TODO Auto-generated method stub
	if(getBal()<amount)
		System.exit(0);
	double d=super.getBal()-amount;
	super.setBal(d);
		return super.getBal();
	}

	@Override
	public double deposite(double amount) {
		// TODO Auto-generated method stub
		double d=super.getBal();
		if(amount>0)
		d=d+amount;
		super.setBal(d);
			return super.getBal();
	
	}

	@Override
	public double calculateGST(double amount) {
		// TODO Auto-generated method stub
		double res=super.getBal()*fivepct;
		return res;
	}
	
}
