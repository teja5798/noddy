package com.cg.service;

public interface GST {
	double fivepct=0.05;
	double twelvepct=0.12;
double calculateGST(double amount);
}
