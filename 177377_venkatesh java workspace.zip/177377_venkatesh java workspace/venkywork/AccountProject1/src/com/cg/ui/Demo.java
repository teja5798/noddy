package com.cg.ui;

import com.cg.bean.Account;
import com.cg.bean.SavingAccount;

public class Demo {
	public static void main(String[] args) {
		Account a=new SavingAccount(101, "venkatesh",2000, 600);
		a.printDetails();
	double w=	a.deposite(3500);
	System.out.println("after deposite balance is  :"+w);
		w=a.withdraw(2500);
		System.out.println("after withdwal balance  is :"+w);
		SavingAccount s=(SavingAccount)a;
	w=s.calculateGST(w);
	System.out.println("GST is "+w);
		
	}

}
