package com.cg.ui;
import com.cg.bean.*;
public class Demo {
public static void main(String[] args) {
	//Shape s=new Shape();//error //interface can not be instantiated
Shape s=new Cricle(15);
s.area();
s=new Rectangle(10,15);
s.area();
Cube c=new Cube(2);
c.area();
c.volume();
s=c;
s.area();
Shape3d sd=c;
sd.volume();
}
}
