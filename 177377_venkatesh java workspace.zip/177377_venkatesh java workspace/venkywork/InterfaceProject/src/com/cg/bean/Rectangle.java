package com.cg.bean;

public class Rectangle implements Shape {
private	double length;
private double breath;
public Rectangle() {
	// TODO Auto-generated constructor stub
}

	public Rectangle(double length, double breath) {
	super();
	this.length = length;
	this.breath = breath;
}

	public double getLength() {
	return length;
}

public void setLength(double length) {
	this.length = length;
}

public double getBreath() {
	return breath;
}

public void setBreath(double breath) {
	this.breath = breath;
}

	@Override
	public void area() {
		// TODO Auto-generated method stub
		double area =2*length*breath;
		System.out.println("Area of the rectangle :"+area);
	}

}
