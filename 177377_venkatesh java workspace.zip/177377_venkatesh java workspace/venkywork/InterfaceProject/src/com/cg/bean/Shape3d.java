package com.cg.bean;

public interface Shape3d {
void volume();
}
