package com.cg.ui;
import com.cg.bean.AccountInformation;
public class Demo {
public static void main(String[] args) {
	AccountInformation ac=new AccountInformation(101, "venky", 2000);
	ac.printDetails();
	//System.out.println("Balance is:"+ac.getBalance());
double d=	ac.withdraw(1000);
	System.out.println("after withdraw Balance is: "+d);
	d=ac.deposite(500);
	System.out.println("after deposit Balance is: "+d);

}
}
