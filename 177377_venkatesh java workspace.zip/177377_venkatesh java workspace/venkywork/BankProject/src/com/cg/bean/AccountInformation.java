package com.cg.bean;

public class AccountInformation {
	private int AcNo;
	private String Customer;
	private double Balance;
	
	public AccountInformation(int acNo, String customer, double balance) {
		AcNo = acNo;
		Customer = customer;
		Balance = balance;
	}
	public int getAcNo() {
		return AcNo;
	}
	public void setAcNo(int acNo) {
		AcNo = acNo;
	}
	public String getCustomer() {
		return Customer;
	}
	public void setCustomer(String customer) {
		Customer = customer;
	}
	public double getBalance() {
		return Balance;
	}
	public void setBalance(double balance) {
		Balance = balance;
	}
	public double withdraw(double amount)
	{
		Balance -=amount;
		return Balance;
	}
	public double deposite(double amount){
		Balance +=amount;
		return Balance;
	}
	public void printDetails() {
		// TODO Auto-generated method stub
System.out.println(AcNo+" "+Customer+" "+Balance);
	}
}
