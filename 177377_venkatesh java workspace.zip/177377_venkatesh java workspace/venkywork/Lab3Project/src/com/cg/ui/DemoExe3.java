package com.cg.ui;
import java.util.Arrays;

import com.cg.lab.Exercise3;
public class DemoExe3 {
public static void main(String[] args) {
	Exercise3 e=new Exercise3();
	int[]a= {63,52,32,89,2,500,1234,671};
	a=e.getSort(a);
	System.out.println(Arrays.toString(a));
}
}
