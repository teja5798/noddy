package com.cg.ui;
import com.cg.lab.Exercise2;
public class DemoExc2 {
public static void main(String[] args) {
	String a[]= {"naga","venkatesh","boppudi","mahesh","venu","viju"};
	Exercise2.stringSort(a);
}
}
