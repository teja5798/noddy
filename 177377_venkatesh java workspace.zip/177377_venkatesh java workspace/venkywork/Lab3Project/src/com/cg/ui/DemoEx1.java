package com.cg.ui;
import com.cg.lab.Exercise1;
public class DemoEx1 {
public static void main(String[] args) {
	Exercise1 e=new Exercise1();
	int a[]= {45,60,20,10,25,3,0,1};
	int i=e.getSecondSmallest(a);
	System.out.println("sceond smallest element:=============> "+i);
}
}
