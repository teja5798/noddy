package com.cg.lab;

import java.util.Arrays;

public class Exercise3 {
public static int[] getSort(int[] a) {
	
	
	
	for (int i = 0; i < a.length; i++) {
		String 	strings=Integer.toString(a[i]);
		System.out.println(a[i]);
		char []rev=strings.toCharArray();
		strings="" ;
		for (int j = rev.length-1; j>=0;j--) {
			strings+=rev[j]+"";
		}
	
		System.out.println(strings);
		a[i]=Integer.parseInt(strings);
		System.out.println(a[i]);
	}	
	
	Arrays.sort(a);
	
	
	return a;	
}
}
