package com.cg.lab;

import java.util.Arrays;

public class Exercise2 {
	public static void stringSort(String a[]) {
		Arrays.sort(a);
		int n=a.length;
		if (n%2==1) {
			n++;
		}
		n/=2;
		//System.out.println(n/=2);
		for (int i = 0; i < n; i++) {
			a[i]=a[i].toUpperCase();
			
		}
		for (String string : a) {
			System.out.print(","+string);
		}
		
	}

}
