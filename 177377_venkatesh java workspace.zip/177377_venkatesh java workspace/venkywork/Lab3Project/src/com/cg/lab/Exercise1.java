package com.cg.lab;

public class Exercise1 {
public int getSecondSmallest(int[]a){
	int tem=0;
	for (int i = 0; i < a.length; i++) {
		for (int j = i+1; j < a.length; j++) {
			if(a[i]>a[j]) {
				tem=a[i];
				a[i]=a[j];
				a[j]=tem;
			}
		}
	}
	return a[1];
	
}
}
