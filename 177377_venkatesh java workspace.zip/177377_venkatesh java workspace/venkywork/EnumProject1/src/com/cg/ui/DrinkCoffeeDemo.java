package com.cg.ui;
import com.cg.bean.*;
public class DrinkCoffeeDemo {
public static void main(String[] args) {
	Coffee c1=new Coffee(Size.LARGE,200.000);
	System.out.println(c1);
}
}
