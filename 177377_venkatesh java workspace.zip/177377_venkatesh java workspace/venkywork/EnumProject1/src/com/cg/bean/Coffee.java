package com.cg.bean;

public class Coffee {
private Size size;
private double price;
public Coffee() {
	// TODO Auto-generated constructor stub
}
public Coffee(Size size, double price) {
	super();
	this.size = size;
	this.price = price;
}
public Size getSize() {
	return size;
}
public void setSize(Size size) {
	this.size = size;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
@Override
public String toString() {
	return "Coffee [size=" + size + ", price=" + price + "]";
}

}
