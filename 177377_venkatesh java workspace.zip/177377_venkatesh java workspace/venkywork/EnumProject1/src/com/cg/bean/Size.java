package com.cg.bean;

public enum Size {
SMALL,MEDIUM,LARGE;

}
//ALL VALUE are  by default public final static
//Size.SMALL=>public final static Size SMALL =new Size();
