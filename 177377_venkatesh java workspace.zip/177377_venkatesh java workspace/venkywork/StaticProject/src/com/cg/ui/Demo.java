package com.cg.ui;

import com.cg.bean.Test;

public class Demo {
public static void main(String[] args) {
	//another class static member can be accessible by class name no need to generate object
	//AS soon as Test is class is loaded
	//static variable are initialized and static block is exactitude
	//static variable are called as class variables
	
	System.out.println(Test.count);
	Test.showCount();
	Test obj=new Test();
	obj.show();
	Test obj2=new Test();
	obj2.show();
}
}
