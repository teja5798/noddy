package com.cg.bean;

public class Test {
int a;//normal variable
public static int count;
static 
{
	count=50;
	System.out.println("static block count "+count);
}
public Test() {
	// TODO Auto-generated constructor stub
a++;
count++;
}
public void show(){
	System.out.println("non static varible a "+a);
	System.out.println("Static variable count "+count);
}
public static void showCount()
{// static block can access only static variables
	//System.out.println("non static varible a "+a);//error 
	System.out.println("Static variable count "+count);
}
}
