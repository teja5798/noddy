package com.cg.bean;

import com.cg.service.AdvanceRemote;

public class SmartTV implements AdvanceRemote {

	@Override
	public void switchOn() {
		// TODO Auto-generated method stub
		System.out.println("Switch on TV");
	}

	@Override
	public void switchOff() {
		// TODO Auto-generated method stub
		System.out.println("Switch Off Tv");
	}

	@Override
	public void accessInternet() {
		// TODO Auto-generated method stub
		System.out.println("access internet");
	}

}
