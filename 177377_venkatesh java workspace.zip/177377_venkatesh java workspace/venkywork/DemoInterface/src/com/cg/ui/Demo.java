package com.cg.ui;
import com.cg.bean.*;
public class Demo {
public static void main(String[] args) {
	SmartTV sm=new SmartTV();
	sm.switchOn();
	sm.accessInternet();
	sm.switchOff();
}
}
