package com.cg.service;

public interface BasicRemote {
void switchOn();
void switchOff();
}
