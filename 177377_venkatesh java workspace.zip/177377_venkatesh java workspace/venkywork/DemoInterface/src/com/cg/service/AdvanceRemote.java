package com.cg.service;
//sub Interface
public interface AdvanceRemote extends BasicRemote {
void accessInternet();
}
