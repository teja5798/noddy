package com.cg.exception;

public class InSufficientBalance extends Exception{
	public InSufficientBalance() {
		// TODO Auto-generated constructor stub
	}
	public InSufficientBalance(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
	@Override
	public String toString() {
		
		return "com.cg.exception.InSufficientBalance" +super.getMessage();
	}
}
