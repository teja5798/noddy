package com.cg.bean;

import com.cg.exception.InSufficientBalance;

public abstract class Account {
	private int Acno;
	private String name;
	private double bal;
	public Account() {
		// TODO Auto-generated constructor stub
	}
	
	public Account(int acno, String name, double bal) {
		super();
		Acno = acno;
		this.name = name;
		try {
			if(bal<500)
				throw new InSufficientBalance(" opening account balance is minimum 500");
		} catch (InSufficientBalance e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}

	public int getAcno() {
		return Acno;
	}
	public void setAcno(int acno) {
		if(acno>0)
		Acno = acno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		if(name!=null || name !=""){
		this.name = name;
		}
	}
	public double getBal() {
		return bal;
	}
	public void setBal(double bal) {
		
	}
	public abstract double withdraw(double amount ) throws InSufficientBalance;
	public abstract double deposite(double amount) ;
	
	public	 void printDetails(){
		System.out.println(Acno+" "+name+" "+bal);
	}
	

}
