package com.cg.bean;

public class Test {
//overloaded method have same name but differs in parameter 
	//either by data type or number of parameter
	//by sequence of parameters
public	void add(String s,String b){
		System.out.println(s+b);
	}
/*public void add(int s,int b){
	System.out.println(s+b);
}
public void add(int s,int b,int c){
	System.out.println(s+b+c);
}
public void add(int a[]){
	int sum=0;
	for (int i : a) {
		sum +=i;
		
	}
	System.out.println(sum);
}*/
public void add(int ...a){
	System.out.println("variable argument ");
	int sum =0;
	for (int i : a) {
		sum =sum+i;
	}
	System.out.println(sum);
}

}
