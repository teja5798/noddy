package com.cg.ui;
import com.cg.bean.*;
public class Demo {
public static void main(String[] args) {
Test ob=new Test();
ob.add("hello", "cg");
ob.add(100, 200);
ob.add(100,1000, 11);
int a[]={3,2,6,9};
ob.add(a);
ob.add(4,5,6,2,3,5);
}
}
