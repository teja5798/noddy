package com.cg.tms.dao;



import java.util.List;



import com.cg.tms.dto.*;



public interface TicketDAO {



 public boolean raiseNewTicket(TicketBean ticketBean);

 List<TicketCategory>listTicketCategory();

}

