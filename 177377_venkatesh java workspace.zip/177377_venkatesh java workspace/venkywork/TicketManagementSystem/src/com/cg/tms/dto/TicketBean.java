package com.cg.tms.dto;



public class TicketBean {



 private String ticketno;

 private String ticketCategoryId;

 private String ticketDescription;

 private String ticketPriority;

 private String ticketStatus;

 private String itimdComments;

 public TicketBean() {

 // TODO Auto-generated constructor stub

 }

 public TicketBean(String ticketno, String ticketCategoryId, String ticketDescription, String ticketPriority)

 {

 this.ticketno = ticketno;

 this.ticketCategoryId = ticketCategoryId;

 this.ticketDescription = ticketDescription;

 this.ticketPriority = ticketPriority;

 }

 public String getTicketno() {

 return ticketno;

 }

 public void setTicketno(String ticketno) {

 this.ticketno = ticketno;

 }

 public String getTicketCategoryId() {

 return ticketCategoryId;

 }

 public void setTicketCategoryId(String ticketCategoryId) {

 this.ticketCategoryId = ticketCategoryId;

 }

 public String getTicketDescription() {

 return ticketDescription;

 }

 public void setTicketDescription(String ticketDescription) {

 this.ticketDescription = ticketDescription;

 }

 public String getTicketPriority() {

 return ticketPriority;

 }

 public void setTicketPriority(String ticketPriority) {

 this.ticketPriority = ticketPriority;

 }

 public String getTicketStatus() {

 return ticketStatus;

 }

 public void setTicketStatus(String ticketStatus) {

 this.ticketStatus = ticketStatus;

 }

 public String getItimdComments() {

 return itimdComments;

 }

 public void setItimdComments(String itimdComments) {

 this.itimdComments = itimdComments;

 }

 @Override

 public String toString() {

 return "ticketno=" + ticketno + "\n ticketCategoryId=" + ticketCategoryId + "\n ticketDescription="

  + ticketDescription + "\n ticketPriority=" + ticketPriority + "\n ticketStatus=" + ticketStatus

  + "\n itimdComments=" + itimdComments;

 }



}

