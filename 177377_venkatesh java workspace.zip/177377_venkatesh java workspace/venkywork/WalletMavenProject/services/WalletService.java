package com.cg.eis.services;

import java.util.Map;

import com.cg.eis.Bean.Account;

public interface WalletService {
String mobilePattern="[0-9] {10}";//10digit pattern for mobile number
public boolean validateMobile(String mobile);
public boolean createAccount(Account ac);
public Account getAccountBymobile(int mobileNo);
public Map<Integer, Account>getAllAccount();

}
