package com.cg.eis.dao;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.cg.eis.Bean.Account;

public class AccountDaoImpl implements AccountDAO  {
//Wallet Account database
	Map<Integer, Account>walletAccounts=new ConcurrentHashMap<>();
/*
 * Method to insert new account in a database
 * 
 * */
@Override
	public boolean createAccount(Account ac) {
	walletAccounts.put(ac.getMobileNo(), ac);
	Account ac1=walletAccounts.get(ac.getMobileNo());
	if (ac1!=null) {
		return true;
	}	
	return false;
	}

	/*
	 * method retrieve account by mobile number from database
	 * */
	@Override
	public Account getAccountBymobile(int mobileNo) {
		//
	Account ac=	walletAccounts.get(mobileNo);
		if(ac!=null)
		return ac;
		else
		return null;
	}

	@Override
	public Map<Integer, Account> getAllAccount() {
		//=>getting all accounts in wallet 
		
		return walletAccounts;
	}

}
