package com.cg.eis.dao;

import java.util.Map;

import com.cg.eis.Bean.Account;

public interface AccountDAO {
	public boolean createAccount(Account ac);
	public Account getAccountBymobile(int mobileNo);
	public Map<Integer, Account>getAllAccount();

}
