package com.cg.eis.services;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.cg.eis.Bean.Account;

class WalletServiceTest {

	@Test
	void test() {
		WalletService service=new WalletServiceImpl();
		System.out.println("testing creat method");
		assertTrue(service.createAccount(new Account(100,"venky",1234567890,500000)));
	}

}
