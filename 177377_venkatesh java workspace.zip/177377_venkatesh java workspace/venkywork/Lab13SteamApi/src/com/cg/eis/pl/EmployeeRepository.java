package com.cg.eis.pl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cg.eis.bean.Department;
import com.cg.eis.bean.Employee;

public class EmployeeRepository {
	

	 public static List<Department> getDepartments()



	 {



	 List<Department> dlist=new ArrayList<>();



	 dlist.add(new Department(10,"IT",100));



	 dlist.add(new Department(20,"Sales",101));



	 dlist.add(new Department(30,"Marketing",102));



	 dlist.add(new Department(40,"HR",104));



	 return dlist;



	 }



	 public static List<Employee> getEmployees()



	 {



	 List<Employee> elist=new ArrayList<>();



	 elist.add(new Employee(100,"Ram","Sinha","ram@cg.com","9867221020",LocalDate.of(2012,5,25),"President",50000.00,null,new Department(10,"IT",100)));



	 elist.add(new Employee(104,"bunny","sunny","sunny@cg.com","9867221100",LocalDate.of(2015,8,2),"Sales_Mgr",45000.00,100,null));



	 elist.add(new Employee(105,"nag","amala","nag@cg.com","8547123069",LocalDate.of(2015,8,2),"Sales_Mgr",45000.00,null,new Department(20,"Sales",101)));







	 elist.add(new Employee(101,"chay","sam","sam@cg.com","9867221020",LocalDate.of(2015,8,2),"Sales_Mgr",45000.00,100,new Department(40,"Sales",101)));



	 elist.add(new Employee(102,"ashu","bushu","bushu@cg.com","8143790342",LocalDate.of(2011,7,21),"Marketing",15000.00,100,new Department(30,"Marketing",102)));



	 elist.add(new Employee(103,"shruthi","frooti","frooti@cg.com","874569632",LocalDate.of(2010,8,2),"Sales_Mgr",45000.00,100,null));



	 elist.add(new Employee(106,"prathamesh","pande","pande@cg.com","8767221020",LocalDate.of(2015,8,2),"Sales_Mgr",45000.00,100,new Department(20,"Sales",101)));



	 return elist;



	 }

}
