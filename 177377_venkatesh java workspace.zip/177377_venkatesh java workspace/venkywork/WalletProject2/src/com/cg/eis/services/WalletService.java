package com.cg.eis.services;

import java.util.Map;

import com.cg.eis.Bean.Account;

public interface WalletService {
String mobilePattern="[6-9][0-9] {9}";//10digit pattern for mobile number
public boolean validateMobile(String mobile);
public boolean createAccount(Account ac);
public Account getAccountBymobile(int mobileNo);
public Map<Integer, Account>getAllAccount();
public boolean transferMoney(double amount,Account a1,Account a2);

}
