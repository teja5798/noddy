package com.cg.eis.pl;
import java.util.Map;
import java.util.Scanner;

import com.cg.eis.Bean.Account;
import com.cg.eis.services.*;
public class MyWallet {
	Scanner sc =new Scanner(System.in);
	private int accountNumber;
	private String custerName;
	private int mobileNo;
	private double balance;
	void custmerDetails(WalletService service) {
		System.out.println("enter the account number");
		this.accountNumber=sc.nextInt();
		System.out.println("enter the hold name");
		this.custerName=sc.next();
		mobileValid(service);
		System.out.println("enter the balance");
		this.balance=sc.nextDouble();
		
		
		
	}
	void mobileValid(WalletService service) {
		System.out.println("enter the mobile number ");
		String mobile=sc.next();
		do{
			System.out.println(service.validateMobile(mobile));
		if(service.validateMobile(mobile)) {
			
			this.mobileNo=Integer.parseInt(mobile);
			System.out.println(mobileNo);
			}
		else
			System.out.println("re-enter the mobile number");
		mobile=sc.next();
	System.out.println(mobileNo);
		}
		while (this.mobileNo!=0);
		
			
		
	}

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		
WalletService service=new WalletServiceImpl();
MyWallet my=new MyWallet();
my.custmerDetails(service);
Account ob1=new Account(my.accountNumber,my.custerName,my.mobileNo,my.balance);
//boolean added=service.createAccount(ob1);
//System.out.println("account add  "+added);
Account ob2=new Account(my.accountNumber,my.custerName,my.mobileNo,my.balance);
boolean ch=service.transferMoney(7000, ob1, ob2);
System.out.println("transaction successfull "+ch);
//added=service.createAccount(ob2);
//System.out.println("account add  "+added);
//Map<Integer, Account>allac=service.getAllAccount();
//System.out.println(allac);
//Account myac=service.getAccountBymobile(1234567891);
//System.out.println(myac);
	}

}
