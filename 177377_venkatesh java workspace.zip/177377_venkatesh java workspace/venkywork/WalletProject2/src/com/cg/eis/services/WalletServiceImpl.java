package com.cg.eis.services;

import java.util.Map;

import com.cg.eis.Bean.Account;
import com.cg.eis.dao.AccountDAO;
import com.cg.eis.dao.AccountDaoImpl;

public class WalletServiceImpl implements WalletService {
/*
 * WalletService is connecting to AccountDAO
 * */
	AccountDAO accountdao=new AccountDaoImpl();
	@Override
	public boolean validateMobile(String mobile) {
		// TODO Auto-generated method stub
		boolean m=false;
		m=mobile.matches(mobilePattern);
		
		return m;
	}

	@Override
	public boolean createAccount(Account ac) {
		// TODO Auto-generated method stub
		return accountdao.createAccount(ac);
	}

	@Override
	public Account getAccountBymobile(int mobileNo) {
		// TODO Auto-generated method stub
		return accountdao.getAccountBymobile(mobileNo);
	}

	@Override
	public Map<Integer, Account> getAllAccount() {
		// TODO Auto-generated method stub
		return accountdao.getAllAccount();
	}

	@Override
	public boolean transferMoney(double amount, Account a1, Account a2) {
		double bal=a1.getBalance()-amount;
		a1.setBalance(bal);
		bal=a2.getBalance()+amount;
		a2.setBalance(bal);
		return accountdao.transferMoney(a1, a2);
	}

}
