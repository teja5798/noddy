package com.cg.eis.dao;

import java.util.Map;

import com.cg.eis.Bean.Account;

public interface AccountDAO {
	public boolean createAccount(Account ac);
	public boolean updateAccount(Account ac);
	public boolean deleteAccount(Account ac);
	public boolean transferMoney(Account a1,Account a2);
	public Account getAccountBymobile(int mobileNo);
	public Map<Integer, Account>getAllAccount();

}
