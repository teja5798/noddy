package com.cg.eis.dao;

import java.sql.*;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.cg.eis.Bean.Account;

public class AccountDaoImpl implements AccountDAO  {
	Connection con;
	PreparedStatement pst;
//Wallet Account database
	Map<Integer, Account>walletAccounts=new ConcurrentHashMap<>();
/*
 * Method to insert new account in a database
 * 
 * */
	private void makeConnection()
	{
		try {
			String url="jdbc:oracle:thin:@10.219.34.3:1521:orcl";
			String user="trg514";
			String pass="training514";
			con=DriverManager.getConnection(url, user, pass);
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
		private void releaseConnection()
		{
			try {
				if(con!=null)
					con.close();
			} catch (SQLException e) {
				// TODO: handle exception
			}
		}
	
@Override
	public boolean createAccount(Account ac) {
	walletAccounts.put(ac.getMobileNo(), ac);
	Account ac1=walletAccounts.get(ac.getMobileNo());
	if (ac1!=null)
	{
		
		try {
			makeConnection();
			pst=con.prepareStatement("insert into Account values(?,?,?,?)");
			pst.setInt(1, ac.getAccountNumber());
			pst.setString(2, ac.getCusterName());
			pst.setInt(3, ac.getMobileNo());
			pst.setDouble(4, ac.getBalance());
		int inset=	pst.executeUpdate();
		System.out.println("Inserted into database  "+inset);
		releaseConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}	
	return false;
	}

	/*
	 * method retrieve account by mobile number from database
	 * */
	@Override
	public Account getAccountBymobile(int mobileNo) {
		//
	Account ac=	walletAccounts.get(mobileNo);
		if(ac!=null)
		return ac;
		else
		return null;
	}

	@Override
	public Map<Integer, Account> getAllAccount() {
		//=>getting all accounts in wallet 
		
		return walletAccounts;
	}

	@Override
	public boolean updateAccount(Account ac) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteAccount(Account ac) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean transferMoney(Account a1, Account a2) 
	{
	boolean transfered=	false;
	try 
	{
	makeConnection();
	con.setAutoCommit(false);
	pst=con.prepareStatement("update account set balance=?where acco=?");
	pst.setDouble(1, a1.getBalance());
	pst.setInt(2, a1.getAccountNumber());
	int u1=pst.executeUpdate();
	System.out.println("updated account1 in database "+u1);
	pst=con.prepareStatement("update account set balance=?where acco=?");
	pst.setDouble(1, a2.getBalance());
	pst.setInt(2, a2.getAccountNumber());
	int u2=pst.executeUpdate();
	System.out.println("up date account2 in data base "+u2);
	walletAccounts.put(a1.getMobileNo(),a1);
	walletAccounts.put(a2.getMobileNo(),a2);
	transfered=true;
	con.commit();
	releaseConnection();
	} catch ( Exception e) {
		try {
			con.rollback();
			releaseConnection();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		e.printStackTrace();
		transfered=false;
	}
		
		
		return transfered;
	}

}
