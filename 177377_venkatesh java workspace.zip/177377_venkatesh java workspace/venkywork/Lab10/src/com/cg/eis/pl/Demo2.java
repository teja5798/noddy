package com.cg.eis.pl;

import com.cg.eis.bean.Exercise2;

public class Demo2 {

	public static void main(String[] args) {
	
		Exercise2 m=new Exercise2();
		Thread th=new Thread(m);
	th.start();
	}

}
