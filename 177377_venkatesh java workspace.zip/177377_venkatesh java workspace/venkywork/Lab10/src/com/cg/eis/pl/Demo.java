package com.cg.eis.pl;
import java.io.IOException;

import com.cg.eis.bean.Exercise1;;

public class Demo {

	public static void main(String[] args)throws InterruptedException {
		
		Exercise1 m=new Exercise1();
try
{
	m.test("source.txt","target.txt");
	m.copycontents();
	
}
catch (Exception e) {
	System.out.println("caught in main"+e.getMessage());
	}

}}
