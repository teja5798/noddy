package com.cg.lab4;

public class Exercise1 {
 public static void cubeNumberSum(int a){
	int sum=0,n=0;
	while(a>0) {
		n=a%10;
		//System.out.println(n);
		sum+=n*n*n;
		a/=10;
	}
	System.out.println("sum of the cubes ===>"+sum);
}
}
