package com.cg.ui;
import com.cg.lab4.Exercise1;
public class Demo {
public static void main(String[] args) {
	Exercise1.cubeNumberSum(024);
}
}
