package com.cg.ui;
import com.cg.bean.Employee;
public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e=new Employee(100,"don",20555);
		e.printDetails();

	}

}
