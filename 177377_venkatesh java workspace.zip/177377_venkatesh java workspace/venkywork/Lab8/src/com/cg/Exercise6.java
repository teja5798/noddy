package com.cg;

import java.time.LocalDate;
import java.time.Period;
import java.util.Date;

public class Exercise6 {
public static void dateCalculation(LocalDate ld) {
	LocalDate l=LocalDate.now();
	Period diff=Period.between(ld, l);
	System.out.println("date differance yyyy/mm/dd :  "+diff.getYears()+"/"+diff.getMonths()+"/"+diff.getDays());
}
}
