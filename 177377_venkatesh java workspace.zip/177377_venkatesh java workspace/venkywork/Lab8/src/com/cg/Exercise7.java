package com.cg;

import java.util.StringTokenizer;

public class Exercise7 {
public static  boolean registeringUserName(String s)
	
{
		if(s.endsWith("_job")) {
			StringTokenizer st=new StringTokenizer(s, "_job");
			int a=st.nextToken().length();
			if(a>8) 
			
				return true;
			else 
				return false;
		}
		else
	return false;
	
}
}
