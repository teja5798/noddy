package com.cg.ui;

import java.time.LocalDate;

import com.cg.Exercise6;

public class Exercise6Demo {
	public static void main(String[] args) {
		LocalDate ld=LocalDate.of(2019,04,12);
		Exercise6.dateCalculation(ld);
	}

}
