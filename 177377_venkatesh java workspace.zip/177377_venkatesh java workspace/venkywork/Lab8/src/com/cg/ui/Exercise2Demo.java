package com.cg.ui;

import java.io.File;

import com.cg.Exercise2;

public class Exercise2Demo {
	public static void main(String[] args) {
		File f=new File("C:\\venkywork\\Lab8\\src\\com\\cg\\ab.txt");
		Exercise2.fileReader(f);
	}
}
