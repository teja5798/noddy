package com.cg.ui;

import java.util.Scanner;

import com.cg.Exercise5;

public class Exercise5Demo {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("please enter a string ");
		String st=sc.next();
	boolean b=	Exercise5.stringCheck(st);
	if(b)
	System.out.println("method type is postive ");
	else
		System.out.println("method type is not postive");
	}

}
