package com.cg.ui;

import com.cg.Exercise7;

public class Exercise7Demo {
	public static void main(String[] args) {
		boolean f=	Exercise7.registeringUserName("venkatesh");
		System.out.println("method "+f);
		}

}
