package com.cg;
import java.io.*;
public class Exercise4 {
public static void fileReader(String file) {
	File fr=new File(file);
	
	if (fr.exists()) {
		System.out.println("file is exists");
	}else {
		System.out.println("file not exit");
	}
	if (fr.canExecute()) {
		System.out.println("file can execute");
	}
	if (fr.canWrite()) {
		System.out.println("file can write ");
	}
	if(fr.canRead()) {
		System.out.println("file can read");
	}
	System.out.println("file name "+file);
	
	if(fr.isDirectory())
	{
		System.out.println(file +" is a Directory");
	}
	
	if(fr.isFile())
	{
		System.out.println(file +" is a File");
	}
	
	//String []type =file.split("\\");
	//System.out.println("The file type is : "+type[1]);
}
public static void main(String[] args) {
	fileReader("C:\\venkywork\\Lab8\\src\\com\\cg\\ab.txt");
	System.out.println("=============================");
	fileReader("C:\\venkywork\\Lab8");
}
}
