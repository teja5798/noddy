package com.cg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Exercise1 {
public static void getStringTokenizer(String string) {
	int sum=0;
	StringTokenizer st=new StringTokenizer(string," ");
	while(st.hasMoreTokens()) {
		int a=Integer.parseInt(st.nextToken());
		 sum+=a;
		System.out.println(a);
	}
	System.out.println(sum);
}
}
