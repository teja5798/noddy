package com.cg;

import java.util.Arrays;
import java.util.Scanner;

public class Exercise5 {
public static boolean stringCheck(String s) {
	char[]a=s.toCharArray();
	//char b[]=a;
	Arrays.sort(a);
	for (int i = 0; i < a.length; i++) {
	if(a[i]!=s.charAt(i)) {
		return false;
	}
	}	
return true;
}
}
