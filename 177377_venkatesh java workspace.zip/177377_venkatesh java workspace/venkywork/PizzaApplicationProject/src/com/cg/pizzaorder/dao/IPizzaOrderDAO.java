package com.cg.pizzaorder.dao;

import com.cg.pizzaorder.bean.*;

public interface IPizzaOrderDAO {
public int placeOrder(Customer customer,PizzaOrder pizza );
public PizzaOrder getOrderDetails(int orderid);
}
