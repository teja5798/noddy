package com.cg.pizzaorder.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.cg.pizzaorder.bean.*;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.service.*;

public class Client {
	int orderId;
	int custId;
	double pizzaPrice;
	String mobilePattern="[0-9]{10}";//10digit pattern for mobile number
	String mobile;
	String address;
	String custmerName;
	LocalDate orderdate;
static Scanner sc=new Scanner(System.in);
 boolean placeOrder()
{ boolean b=false;
	 System.out.println("Enter your name");
custmerName=sc.next();
System.out.println("Enter Your Address");
address=sc.next();
System.out.println("Enter your mobile number");
String mobile=sc.next();
custId=(int)(Math.random()*10000);//taking random values
orderId=(int) (Math.random()*10000);//taking random values
do {
	if(mobile.matches(mobilePattern)) //pattern checking
	{
		this.mobile=mobile;
	pizzaToppins();
	 dipaly();
	 b=true;
	}
	else {
		System.out.println("Re-enter the details");
		mobile=sc.next();
	
		}
}while(b!=true);
	
	return b;
}
 double pizzaToppins() {
	 int rs=0;
	 String size="";
	 System.out.println("Choose option \n1 Capsicu Rs:30\n2 Mushroom RS:50\n3 Jalapeno Rs:70\n4 Paneer Rs:85");
	 size=sc.next();
	 if(size.equalsIgnoreCase("Capsicu"))
	 rs=30;
	 else if(size.equalsIgnoreCase("Mushroom"))
	 rs=50;
	 else if(size.equalsIgnoreCase("Jalapeno"))
		 rs=70;
	 else if(size.equalsIgnoreCase("Paneer"))
		 rs=85;
	return pizzaPrice=350+rs;
	 
 }
 void dipaly(){
	 System.out.println("Your pizz order is placed with Order Id: "+orderId);
	
	 
	 
	 
 }
 static void exit(int a) {
	System.exit(a);
 }
 
public static void main(String[] args) throws PizzaException {
		// TODO Auto-generated method stub
	Client c=new Client();
	boolean b= c.placeOrder();
	
	PizzaOrder po=new PizzaOrder(c.orderId,c.custId,c.pizzaPrice);//passing values
	Customer co=new Customer(c.custId,c.custmerName,c.address,c.mobile);
	IPizzaOrderService isr=new PizzaOrderService();
	isr.placeOrder(co, po);
	po=isr.getOrderDetails(c.orderId);
	if (b) {
		 System.out.println(po);
	}
   System.out.println("if want to exit press any number");
   exit(sc.nextInt());
   
	}


}
