package com.cg.pizzaorder.service;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.*;
import com.cg.pizzaorder.exception.PizzaException;

public class PizzaOrderService implements IPizzaOrderService {
	   IPizzaOrderDAO	 dao=new PizzaOrderDAO();

	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza)throws PizzaException {
		// TODO Auto-generated method stub
		
		return dao.placeOrder(customer, pizza);
	}

	@Override
	public PizzaOrder getOrderDetails(int orderid)throws PizzaException {
		// TODO Auto-generated method stub
		return dao.getOrderDetails(orderid);
	}

}
