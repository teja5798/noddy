package com.cg.pizzaorder.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;

public class PizzaOrderDAO implements IPizzaOrderDAO {
	Map<Integer, PizzaOrder>pizzaEntry=new HashMap<>();
	Map<Integer, Customer>customerEntry=new HashMap<>();
	

	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza) {
		pizzaEntry.put(pizza.getOrderId(), pizza);
		customerEntry.put(customer.getCustomerId(),customer);
		
		return pizza.getOrderId();
	}

	@Override
	public PizzaOrder getOrderDetails(int orderid) {
		// TODO Auto-generated method stub
		PizzaOrder order=	pizzaEntry.get(orderid);
		return order;
	}

}
