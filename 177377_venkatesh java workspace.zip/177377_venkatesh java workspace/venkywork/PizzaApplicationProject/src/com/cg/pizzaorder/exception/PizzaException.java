package com.cg.pizzaorder.exception;

public class PizzaException extends Exception {
	public PizzaException() {
		// TODO Auto-generated constructor stub
	}
public PizzaException(String message) {
	super(message);//passing message to super class
}
@Override
public String toString() {
	// TODO Auto-generated method stub
	return"com.cg.pizzaorder.exception"+super.getMessage();//we get message here
}
}
