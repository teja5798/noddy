package com.cg.cms.service;

import java.util.List;

import com.cg.cms.dao.CabDAO;
import com.cg.cms.dao.CabDAOImpl;
import com.cg.cms.dto.CabBean;
import com.cg.cms.dto.CabCategory;
import com.cg.cms.exception.CabManagementException;

public class CabServiceImpl implements CabService{
	CabDAO cabDAO = null;
	@Override
	public boolean bookCab(CabBean cabBean) throws CabManagementException {
		cabDAO = new CabDAOImpl();
		int cabNo = (int)(Math.random()*1000);
		String cabNoString = String.valueOf(cabNo);
		cabBean.setCabNo(cabNoString);
		boolean booked = cabDAO.bookCab(cabBean);
		return booked;
	}
	
	@Override
	public List<CabCategory> listCabCatetory() throws CabManagementException {

		cabDAO = new CabDAOImpl();
		return cabDAO.listCabCategory();
	}



}
