package com.cg.cms.ui;
import java.nio.channels.NetworkChannel;
import java.util.List;
import java.util.Scanner;

import javax.xml.ws.AsyncHandler;

import com.cg.cms.dto.CabBean;
import com.cg.cms.dto.CabCategory;
import com.cg.cms.exception.CabManagementException;
import com.cg.cms.service.CabService;
import com.cg.cms.service.CabServiceImpl;


public class MainUI {

	static Scanner scanner = new Scanner(System.in);
	static CabService cabService = null;
	static CabBean cabBean = null;
	public static void main(String[] args) {
		MainUI mainUI = new MainUI();	
		boolean response=false;
		do {
			try {
			System.out.println("Welcome to Cab Service Help Desk");
			System.out.println("1. Book a Cab \n2. Exit from a system");
			switch(Integer.parseInt(scanner.next().trim())) {
			case 1: mainUI.bookCab();
				break;
			case 2:System.exit(0);//exiting from application
				break;
			default:System.out.println("Enter a valid option.");//error for incorrect option
				break;
			}
			}catch(CabManagementException e) {
				System.out.println(e.getMessage());
			}
			catch (NumberFormatException e) {
				System.out.println("Give option with currect format");
			}
		}while(!response);
	}
	
	private  boolean bookCab() throws CabManagementException{
		displayCabCateogries();
		cabService = new CabServiceImpl();
		System.out.println("Select Cab Category : ");
		int selectedCategory = scanner.nextInt();
		List cabCategoriesList = cabService.listCabCatetory();
	    CabCategory selectedCabCategory = (CabCategory)cabCategoriesList.get(selectedCategory);
		
	    CabBean cabBean = new CabBean();
	    cabBean.setCabCategoryId(selectedCabCategory.getCabCategoryId());
	    //scan all the others values and add to cabBean
	    cabBean.setCabDescription("cab to mars");
	    System.out.println("Enter priority");
	    try {
	    	int number = scanner.nextInt();
	    	if(number <1 && number >3) {
	    		throw new CabManagementException("Enter a valid option 1,2,3...");	
	    	}
	    }
	    catch(Exception exception) {
	    	System.out.println(exception.getMessage());
	    	return false;
	    }
	    cabBean.setCabPriority("high");
	    cabBean.setCabStatus("new");
	    cabService = new CabServiceImpl();
	    boolean bookingStatus = cabService.bookCab(cabBean);
	    return bookingStatus;
	}
	private  void displayCabCateogries() throws CabManagementException{
		CabService cabService = new CabServiceImpl();
		List cabCategoriesList = cabService.listCabCatetory();
		for(int index=0; index < cabCategoriesList.size(); index++)
		{ CabCategory cabCategory = (CabCategory) cabCategoriesList.get(index);
			System.out.println(index+1 +": "+ cabCategory.getCategoryName());
		}
	}
	
}