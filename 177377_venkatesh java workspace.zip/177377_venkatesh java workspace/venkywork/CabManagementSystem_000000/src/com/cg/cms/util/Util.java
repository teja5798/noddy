package com.cg.cms.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.cms.dto.CabBean;

public class Util {

	//HashMap to store cab categories.
	private static Map<String, String> cabCategory = new HashMap<String, String>();
	//hashmap for booked cabs
	private static Map<String, CabBean> cabsBooked = new HashMap<String, CabBean>();
	
	//Return all the cab categories
	public static Map<String, String> getcabCategoryEntries(){
		//adding cab cateogries to the HashMap.
		cabCategory.put("c001", "sedan");
		cabCategory.put("c002", "prime");
		cabCategory.put("c003", "luxury");
		
		return cabCategory;
	}
	
	//return booked cabs HashMap
	public static Map<String, CabBean> getCabsBooked(){
		return cabsBooked;
	}
}
