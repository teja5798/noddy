package com.cg.cms.dto;

public class CabCategory {
	
	private String cabCategoryId;

	private String categoryName;

	public CabCategory() {
		super();
	}

	public CabCategory(String cabCategoryId, String categoryName) {
		super();
		this.cabCategoryId = cabCategoryId;
		this.categoryName = categoryName;
	}

	public String getCabCategoryId() {
		return cabCategoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}
	public void setCabCategoryId(String cabCategoryId) {
		this.cabCategoryId = cabCategoryId;
	}
	
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	
}
