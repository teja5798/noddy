package com.cg.cms.service;

import java.util.List;

import com.cg.cms.dto.CabBean;
import com.cg.cms.dto.CabCategory;
import com.cg.cms.exception.CabManagementException;


public interface CabService {
	boolean bookCab(CabBean cabBean) throws CabManagementException;
	List<CabCategory> listCabCatetory() throws CabManagementException;
}
