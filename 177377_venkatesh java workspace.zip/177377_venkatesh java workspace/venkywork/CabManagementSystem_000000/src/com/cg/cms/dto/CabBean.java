package com.cg.cms.dto;

import java.time.LocalDateTime;

public class CabBean {

	private String cabNo;
	private String cabCategoryId;
	private String cabDescription;
	private String cabPriority;
	private String cabStatus;
	private LocalDateTime rDate;
	
	public CabBean() {
		super();
	}
	public CabBean(String cabNo, String cabCategoryId, String cabDescription, String cabPriority, String cabStatus,
			LocalDateTime rDate) {
		super();
		this.cabNo = cabNo;
		this.cabCategoryId = cabCategoryId;
		this.cabDescription = cabDescription;
		this.cabPriority = cabPriority;
		this.cabStatus = cabStatus;
		this.rDate = rDate;
	}
	public String getCabCategoryId() {
		return cabCategoryId;
	}
	public String getCabDescription() {
		return cabDescription;
	}
	public String getCabNo() {
		return cabNo;
	}
	public String getCabPriority() {
		return cabPriority;
	}
	public String getCabStatus() {
		return cabStatus;
	}
	public LocalDateTime getrDate() {
		return rDate;
	}
	public void setCabCategoryId(String cabCategoryId) {
		this.cabCategoryId = cabCategoryId;
	}
	public void setCabDescription(String cabDescription) {
		this.cabDescription = cabDescription;
	}
	public void setCabNo(String cabNo) {
		this.cabNo = cabNo;
	}
	public void setCabPriority(String cabPriority) {
		this.cabPriority = cabPriority;
	}
	public void setCabStatus(String cabStatus) {
		this.cabStatus = cabStatus;
	}
	public void setrDate(LocalDateTime rDate) {
		this.rDate = rDate;
	}
}
