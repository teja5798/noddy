package com.cg.cms.exception;

public class CabManagementException extends Exception{
	
public CabManagementException() {
	
}
public CabManagementException(String message) {
	super(message);
}
}
