package com.cg.pizzaorder.ui;
/* Header Comment
 * Author: Niveditha K
 * Employee Id: 177549
 * Created On: 19/04/2019
 * Description: Pizaa Order Application
 */


import java.time.LocalDate;
import java.util.Scanner;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.service.IPizzaOrderService;
import com.cg.pizzaorder.service.PizzaOrderService;

public class Client {
	
	static Scanner scan=new Scanner(System.in);
	
	static String custName;
	static String address;
	static String phone;
	static String topping;
	static LocalDate date;
	static boolean res=false;
	static IPizzaOrderService iser=null;
	static double P=350;
	static double totalPrice=0;
	

	public static void main(String[] args) {
		
		String h=null;
		
		do
		{
			
			System.out.println("Select the your choice from 1-3 where ");
			System.out.println("1. Place Order\n2. Display Order\n3. Exit Id\nAvailable Toppings are : Capsicum, Mushroom, Jalapeno, Paneer");
			int n=scan.nextInt();
			switch (n) {
				case 1:
					int finalorderid=placeOrder();
					System.out.println("Pizza Order successfully placed with Order Id: "+finalorderid);
					break;
				case 2:
					System.out.println("Enter the Order Id to be viewe the details:");
					int orderId=scan.nextInt();
					getOrderDetails(orderId);
					break;
				case 3:
					System.out.println("Program Terminated");
					System.exit(0);
					break;
				default:
					System.out.println("choose your proper choice from 1-3");
					n=scan.nextInt();
					break;
			}
					System.out.println("do you want to continue y/n");
					h=scan.next();
					if(h.equalsIgnoreCase(h))
					{
						System.out.println("Program Terminated");
					}
		}
		while(h.equalsIgnoreCase("y"));
		
	}
		
	private static PizzaOrder getOrderDetails(int orderId) {
		iser=new PizzaOrderService();
		return iser.getOrderDetails(orderId);
	}

	private static int placeOrder()
	{
		iser=new PizzaOrderService();
		
		//validation
		do
		{
			try
			{
				System.out.println("Enter the name of the customer : ");
				custName=scan.next();
				res=iser.validateCustName(custName);
			}
			catch(ArithmeticException e)
			{
				System.out.println(e.getMessage());
			}
					
		}while(!res);
		
		res=false;
		do
		{
			try
			{
				System.out.println("Enter customer address : ");
				address=scan.next();
				res=iser.validateAddress(address);
			}
			catch(ArithmeticException e)
			{
				System.out.println(e.getMessage());
			}
					
		}while(!res);
		
		
		res=false;
		do
		{
			try
			{
				System.out.println("Enter customer phone number : ");
				phone=scan.next();
				res=iser.validatePhone(phone);
			}
			catch(ArithmeticException e)
			{
				System.out.println(e.getMessage());
			}
					
		}while(!res);
		
		res=false;
		do
		{
			try
			{
				System.out.println("Type of Pizza Topping preferred : ");
				topping=scan.next();
				res=iser.validateTopping(topping);
			}
			catch(ArithmeticException e)
			{
				System.out.println(e.getMessage());
			}
					
		}while(!res);
		
		if(topping.equalsIgnoreCase("capsicum"))
		{
			totalPrice=P+30;
			System.out.println("Prize : "+totalPrice);
		}
		if(topping.equalsIgnoreCase("mushroom"))
		{
			totalPrice=P+50;
			System.out.println("Prize : "+totalPrice);
		}
		if(topping.equalsIgnoreCase("jalapeno"))
		{
			totalPrice=P+70;
			System.out.println("Prize : "+totalPrice);
		}
		if(topping.equalsIgnoreCase("paneer"))
		{
			totalPrice=P+85;
			System.out.println("Prize : "+totalPrice);
		}
		
		date=LocalDate.now();
		System.out.println("Order Date : "+date);
		
		Customer customer=new Customer(custName,address,phone,topping,date,totalPrice);
		PizzaOrder pizza= new PizzaOrder(totalPrice);
		iser=new PizzaOrderService();
		int orderId=iser.placeOrder(customer,pizza);
		return orderId;
		
	}
	

}
