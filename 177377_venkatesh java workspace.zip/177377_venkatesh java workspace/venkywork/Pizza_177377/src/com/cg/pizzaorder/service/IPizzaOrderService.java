package com.cg.pizzaorder.service;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;

public interface IPizzaOrderService {

	public int placeOrder(Customer customer,PizzaOrder pizza);
	public PizzaOrder getOrderDetails(int orderId);
	
	public boolean validateCustName(String cust);
	public boolean validateAddress(String address);
	public boolean validatePhone(String phone);
	public boolean validateTopping(String topping);

}
