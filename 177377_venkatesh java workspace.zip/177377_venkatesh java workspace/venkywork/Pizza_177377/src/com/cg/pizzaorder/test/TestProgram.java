package com.cg.pizzaorder.test;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.IPizzaOrderDAO;
import com.cg.pizzaorder.dao.PizzaOrderDAO;



public class TestProgram {

	IPizzaOrderDAO pdao1=null;
	
	@Before
	public void Init()
	{
		pdao1= new PizzaOrderDAO() ;
	}
	
	@After
	public void Termi()
	{
		pdao1=null;
	}
	@Test
	public void testPlaceOrder()
	{
		Customer cust=new Customer("Niveditha","bangalore","9901771876","paneer",'(2019-04-19)',400);
		cust.setCustomerId(10001);
		int cid=pdao1.placeOrder(cust.getCustomerId());
		Assert.assertEquals(cid, 10001);
		
	}
	public void testgetOrderDetails()
	{
		PizzaOrder rech=new PizzaOrder(100);
		rech.setOrderId(1542);
		pdao1.getOrderDetails(rech.getOrderId());
		Assert.assertNotNull(pdao1);
	}
	
}

