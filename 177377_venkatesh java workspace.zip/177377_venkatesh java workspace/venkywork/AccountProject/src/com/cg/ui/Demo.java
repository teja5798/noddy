package com.cg.ui;

import com.cg.bean.Account;
import com.cg.bean.SavingAccount;

public class Demo {
	public static void main(String[] args) {
		Account a=new SavingAccount(101, "venkatesh",2000, 600);
		a.printDetails();
	double w=	a.deposite(2000);
	System.out.println("after deposite balance is  :"+w);
		w=a.withdraw(2500);
		System.out.println("after withdwal balance  is :"+w);
		
		
	}

}
