package com.cg.bean;

public abstract class Account {
	private int Acno;
	private String name;
	private double bal;
	public Account() {
		// TODO Auto-generated constructor stub
	}
	
	public Account(int acno, String name, double bal) {
		super();
		Acno = acno;
		this.name = name;
		this.bal = bal;
	}

	public int getAcno() {
		return Acno;
	}
	public void setAcno(int acno) {
		if(acno>0)
		Acno = acno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		if(name!=null || name !=""){
		this.name = name;
		}
	}
	public double getBal() {
		return bal;
	}
	public void setBal(double bal) {
		if(bal >=0)
		this.bal = bal;
	}
	public abstract double withdraw(double amount );
	public abstract double deposite(double amount);
	
	public	 void printDetails(){
		System.out.println(Acno+" "+name+" "+bal);
	}
	

}
