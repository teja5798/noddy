package com.cg.bean;

public class Analyst extends Employee {
	String project;
	public Analyst() {
		// TODO Auto-generated constructor stub
	}
	public Analyst(int eid,String ename,double salary,String project){
		super(eid,ename,salary);//super class parameterized constractor must be first line
		//super class variable or function methode or constractor can be called using keyword super
		//super.eid=eid //pravite will not accessible even in sub class
		this.project=project;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	
	public void printDetails(){
		super.printDetails();
		System.out.println("Project :"+project);
	}
}
