package com.cg.ui;
import com.cg.bean.*;
public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e=new Manager(101,"manager",500050.000,"IT");
		e.printDetails();//manager printDetails
		//String dept=e.getDepartment();//error
		Manager m=(Manager) e;//change e type to manager type and store 
		//object type casting //if u give wrong type then it give class cast Exception
		String dept=m.getDepartment();
		System.out.println(dept);
	}

}
