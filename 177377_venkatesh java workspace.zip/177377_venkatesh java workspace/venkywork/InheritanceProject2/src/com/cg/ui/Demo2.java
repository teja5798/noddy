package com.cg.ui;
import com.cg.bean.*;
public class Demo2 {
public static	void calculateBonus(Employee e){
		double bonus;
		if(e instanceof Manager)
			bonus=e.getSalary()*0.50;
		else if (e instanceof Analyst) {
			bonus=e.getSalary()*0.30;
		
		}else {
			bonus=e.getSalary()*0.20;
		}
		System.out.println("bonus :"+bonus);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Employee e=new Employee(100,"Ram",25000.00);

e.printDetails();
calculateBonus(e);
e=new Manager(101,"manager",50000.000,"IT");
e.printDetails();//sub class object calls super class method
calculateBonus(e);
e=new Analyst(102,"kanth",40000,"JAVA FULL STACK");
e.printDetails();
calculateBonus(e);
	}

}
