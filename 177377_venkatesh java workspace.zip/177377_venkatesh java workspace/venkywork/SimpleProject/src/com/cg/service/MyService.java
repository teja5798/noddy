package com.cg.service;
@FunctionalInterface
public interface MyService {
String wish="WELCOME TO CAPGEMINI";
void createWish(String customewish);
//jdk 1.8 onwords 
public default void display()
{
	System.out.println("Default method : "+wish);
}
public static void mywish(){
	System.out.println("static inter face method ");
}
}
