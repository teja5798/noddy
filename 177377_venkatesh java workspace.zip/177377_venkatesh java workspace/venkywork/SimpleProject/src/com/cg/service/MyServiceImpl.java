package com.cg.service;

public class MyServiceImpl implements MyService {

	@Override
	public void createWish(String customewish) {
		// TODO Auto-generated method stub
		System.out.println(customewish);
	}
//no need to implement the default method
}
