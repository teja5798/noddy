package com.cg.ui;
import com.cg.service.*;
public class Demo {
public static void main(String[] args) {
	MyService.mywish();
	MyService m=new MyServiceImpl();
	m.createWish("good afernoon");
	m.display();
}
}
