package com.cg.ui;
import com.cg.lab.Exercise4Exception;;
public class DemoEx3 {
	static void employeeName(String fname,String lname){
		if (fname.isEmpty()|lname.isEmpty()) {
			try {
				throw new Exercise4Exception("\n please enter the names correctly");
			} catch (Exercise4Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
employeeName("", "");
	}

}
