package com.cg.ui;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.print.DocFlavor.INPUT_STREAM;

import com.cg.lab.Exercies1;
public class DemoEx1 {
public static void main(String[] args) throws IOException {
	Exercies1 e=new Exercies1();
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	e.trafficSignals(br.readLine());
}
}
