package com.cg.ui;

import com.cg.lab.Exercise2;

public class DemoEx2 {
public static void main(String[] args) {
	Exercise2 e=new Exercise2();
	e.nonRecursive(5);
}
}
