package com.cg.lab;

public class Exercies1 {
	public void trafficSignals(String s) {
		if(s.equalsIgnoreCase("red"))
			System.out.println("stop");
		else if (s.equalsIgnoreCase("green")) {
			System.out.println("go");
		}else if (s.equalsIgnoreCase("yellow")) {
			System.out.println("ready");
		}
	}

}
