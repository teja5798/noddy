package com.cg.lab;

public class EmployeeSalary {
public static void slary(double sal){
	if (sal<3000) {
		try {
			throw new EmployeeException("\n"+sal+" salary is below 3000Rs ");
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			
	}else {
		System.out.println("Your salary is  => "+sal);
	}
}
public static void main(String[] args) {
	slary(2999);
}
}
