package com.cg.lab;

public class Exercise2 {
	int a=1;
	int b=1;
public void nonRecursive(int i) {
	System.out.print(a+","+b);
	while(i>0) {
		int c=a+b;
		a=b;
		b=c;
		System.out.print(","+c);
		i--;
	}
	
}
public int Recursive(int i) {
	
	
	
	return 0;
}
}
