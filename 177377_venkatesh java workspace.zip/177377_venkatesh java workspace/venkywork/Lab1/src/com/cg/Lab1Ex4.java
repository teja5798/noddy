package com.cg;

import java.util.*;
class Lab1Ex4
{
//programcheck if a number is a power of two or not
static boolean checkNumber(int n)
{
int N=n;
int s=1;
n=n/2;
boolean f=false; 
while(n!=0)
{

s *=2;
if(N==s)
{
f=true;
}
n--;
}

return f;
}
public static void main(String[]args)
{
Scanner sc=new Scanner(System.in);
System.out.println("enter number");
int a=sc.nextInt();
boolean Sum =checkNumber(a);
if(Sum)
System.out.println(" power of 2 ");
else
System.out.println(" NOT power of 2 ");
}
}