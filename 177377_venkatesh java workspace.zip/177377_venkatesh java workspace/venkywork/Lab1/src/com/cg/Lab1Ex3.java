package com.cg;
import java.util.*;
class Lab1Ex3
{
//programcheck if a number is increaseing or not
static boolean checkNumber(int n)
{
int N=n;
boolean f=true; 
while(n!=0)
{
int i1=n%10;
n=n/10;
int i2=n%10;
if(i1<i2)
{
f=false;
}
}
return f;
}
public static void main(String[]args)
{
Scanner sc=new Scanner(System.in);
System.out.println("enter number");
int a=sc.nextInt();
boolean Sum =checkNumber(a);
if(Sum)
System.out.println(" increacing  number ");
else
System.out.println(" NOT increacing  number ");
}
}