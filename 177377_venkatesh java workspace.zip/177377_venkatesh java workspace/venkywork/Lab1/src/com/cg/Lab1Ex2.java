package com.cg;
import java.util.*;
class Lab1Ex2
{
static int calculateDifference(int n)
{int sum=0,s=0,m,sum1=0;
for (int i = 0; i <=n; i++) {
	sum+=i*i;
	sum1 +=i;
	s=sum1*sum1;
}
m=sum-s;
	return m;
}
public static void main(String[]args)
{
Scanner sc=new Scanner(System.in);
System.out.println("enter number");
int a=sc.nextInt();
int Sum =calculateDifference(a);
System.out.println("diffirence of numbers  "+Sum);
}
}