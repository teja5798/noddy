package com.cg;

import java.util.Scanner;
class Lab1Ex1
{
//program for sum of n natural numbers which are divisible by 3or5
static int calculateSum(int n)
{
int Sum=0; 
while(n!=0)
{
if(n%3==0||n%5==0)
{
Sum +=n; //sum numbers divisible by 3or5
}
--n;
}
return Sum;
}
public static void main(String[]args)
{
Scanner sc=new Scanner(System.in);
System.out.print("enter number");
int a=sc.nextInt();
int Sum =calculateSum(a);
System.out.println("Sum numbers Which are divisible by 3&5: "+Sum);
}
}