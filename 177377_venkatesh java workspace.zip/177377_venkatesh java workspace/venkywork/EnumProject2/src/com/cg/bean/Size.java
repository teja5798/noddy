package com.cg.bean;

public enum Size {
SMALL(100),
MEDIUM(200),
LARGE(300);
private int ml;
private Size(int ml) {
// TODO Auto-generated constructor stub
this.ml=ml;
}
public int getML(){
	return ml;
}
}
//ALL VALUE are  by default public final static
//Size.SMALL=>public final static Size SMALL =new Size();
