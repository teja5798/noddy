package com.cg.ui;
import com.cg.bean.*;
public class DrinkCoffeeDemo {
public static void main(String[] args) {
	Coffee c1=new Coffee(Size.LARGE,200.000);
	System.out.println(c1);
	Size s=c1.getSize();
	int ml=s.getML();
	System.out.println("quantity "+ml+"ml");

	c1=new Coffee(Size.SMALL,200.000);
	System.out.println(c1);
	 s=c1.getSize();
	 ml=s.getML();
	System.out.println("quantity "+ml+"ml");
	c1=new Coffee(Size.MEDIUM,200.000);
	System.out.println(c1);
	 s=c1.getSize();
	 ml=s.getML();
	System.out.println("quantity "+ml+"ml");
}
}
