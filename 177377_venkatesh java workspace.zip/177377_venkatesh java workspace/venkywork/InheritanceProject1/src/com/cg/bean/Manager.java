package com.cg.bean;
//sub class Extends common data (properties)$function(behavior)
public class Manager extends Employee {
	//special data
private String department;
public Manager() {
	// TODO Auto-generated constructor stub
}
public Manager(int eid,String ename,double salary,String department){
	super(eid,ename,salary);//super class parameterized constructor must be first
	this.department=department;
}
public String getDepartment() {
	return department;
}
public void setDepartment(String department) {
	this.department = department;
}

}
