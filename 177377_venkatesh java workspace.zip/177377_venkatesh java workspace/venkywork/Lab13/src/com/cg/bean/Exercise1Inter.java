package com.cg.bean;

public interface Exercise1Inter {
public  int power(int x,int y);
}
