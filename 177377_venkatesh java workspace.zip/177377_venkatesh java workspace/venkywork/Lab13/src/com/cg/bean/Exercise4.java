package com.cg.bean;

public interface Exercise4 {
	public void bigger(int a, int b);
}
