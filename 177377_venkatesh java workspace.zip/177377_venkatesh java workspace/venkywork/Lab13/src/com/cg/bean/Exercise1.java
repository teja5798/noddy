package com.cg.bean;

public class Exercise1 {
public static void main(String[] args) {
	Exercise1Inter ex=(x,y)->{return (int) Math.pow(x, y);};
	int res=ex.power(4,2);
	System.out.println("power of "+res);
}
}
