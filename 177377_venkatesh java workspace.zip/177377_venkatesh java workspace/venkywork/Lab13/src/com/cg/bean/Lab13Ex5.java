package cg.bean;

public interface Lab13Ex5 {
	
	public void fact(int a);
	
	

}
